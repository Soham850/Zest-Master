import json
from dataclasses import asdict
from core.models import TournamentState

def save_state(state: TournamentState, filepath: str):
    data = {
        "state_version": 1,
        "payload": asdict(state)
    }
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def load_state(filepath: str) -> TournamentState:
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    # version check
    version = data.get("state_version", 1)
    payload = data["payload"]
    return reconstruct_state(payload, version)
