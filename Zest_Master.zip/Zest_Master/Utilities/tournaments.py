import streamlit as st

def render():
    st.title("Tournaments")
    st.write("Tournament manager UI coming here.")
