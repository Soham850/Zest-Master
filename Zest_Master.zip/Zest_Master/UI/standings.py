import streamlit as st
from pathlib import Path
import json

DATA_DIR = Path("data/tournaments/active")


def load_state(slug):
    path = DATA_DIR / slug / "state.json"
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def compute_group_standings(state):
    """
    Compute per-pool group standings using existing match MP/BP.
    No mutation, no override, uses same scoring already stored.
    Returns: dict { pool_name: [ (mp, bp, tid) sorted ] }
    """
    if "group" not in state:
        return {}

    standings_by_pool = {}
    for pool in state["group"].get("pools", []):
        tbl = []
        for tid in pool["team_ids"]:
            mp = bp = 0
            for rnd in pool["rounds"]:
                for match in rnd["matches"]:
                    if "bye" in match:
                        continue
                    if match.get("status") != "done":
                        continue
                    if match["white"] == tid:
                        mp += match["mp1"]
                        bp += match["bp1"]
                    elif match["black"] == tid:
                        mp += match["mp2"]
                        bp += match["bp2"]
            tbl.append((mp, bp, tid))
        tbl.sort(reverse=True)
        standings_by_pool[pool["name"]] = tbl
    return standings_by_pool


def compute_swiss_standings_live(state):
    """Compute swiss standings in live mode (matches completed so far)."""
    swiss = state.get("swiss")
    if not swiss:
        return []
    teams = swiss.get("teams", [])
    rounds = swiss.get("rounds", [])

    # MP, BP, TB (Buchholz) computed same as swiss_stage
    standings = []
    for tid in teams:
        mp = bp = 0
        for rnd in rounds:
            for match in rnd.get("matches", []):
                if "bye" in match:
                    if match["bye"] == tid:
                        mp += 1
                    continue
                if match.get("status") != "done":
                    continue
                if match["white"] == tid:
                    mp += match["mp1"]
                    bp += match["bp1"]
                elif match["black"] == tid:
                    mp += match["mp2"]
                    bp += match["bp2"]

        # compute Buchholz: sum of opponents MP
        buch = 0
        opps = []
        for rnd in rounds:
            for match in rnd.get("matches", []):
                if "bye" in match:
                    continue
                if match["white"] == tid:
                    opps.append(match["black"])
                elif match["black"] == tid:
                    opps.append(match["white"])
        for opp in opps:
            opp_mp = 0
            for rnd in rounds:
                for match in rnd.get("matches", []):
                    if "bye" in match:
                        continue
                    if match.get("status") != "done":
                        continue
                    if match["white"] == opp:
                        opp_mp += match["mp1"]
                    elif match["black"] == opp:
                        opp_mp += match["mp2"]
            buch += opp_mp

        standings.append((mp, bp, buch, tid))

    standings.sort(reverse=True)
    return standings


def compute_swiss_standings_end_of_round(state):
    """Compute swiss standings using only locked rounds."""
    swiss = state.get("swiss")
    if not swiss:
        return []
    teams = swiss.get("teams", [])
    rounds = swiss.get("rounds", [])

    standings = []
    for tid in teams:
        mp = bp = 0
        for rnd in rounds:
            if not rnd.get("locked", False):
                continue
            for match in rnd.get("matches", []):
                if "bye" in match:
                    if match["bye"] == tid:
                        mp += 1
                    continue
                if match.get("status") != "done":
                    continue
                if match["white"] == tid:
                    mp += match["mp1"]
                    bp += match["bp1"]
                elif match["black"] == tid:
                    mp += match["mp2"]
                    bp += match["bp2"]

        # Buchholz
        buch = 0
        opps = []
        for rnd in rounds:
            if not rnd.get("locked", False):
                continue
            for match in rnd.get("matches", []):
                if "bye" in match:
                    continue
                if match["white"] == tid:
                    opps.append(match["black"])
                elif match["black"] == tid:
                    opps.append(match["white"])
        for opp in opps:
            opp_mp = 0
            for rnd in rounds:
                if not rnd.get("locked", False):
                    continue
                for match in rnd.get("matches", []):
                    if "bye" in match:
                        continue
                    if match.get("status") != "done":
                        continue
                    if match["white"] == opp:
                        opp_mp += match["mp1"]
                    elif match["black"] == opp:
                        opp_mp += match["mp2"]
            buch += opp_mp

        standings.append((mp, bp, buch, tid))

    standings.sort(reverse=True)
    return standings


def render(slug):
    if slug is None:
        st.info("No active tournament selected.")
        return

    state = load_state(slug)
    if state is None:
        st.error("Cannot load tournament.")
        return

    st.title("Standings")

    tabs = st.tabs(["Group", "Swiss", "Individual"])

    # ------------------------------
    # TAB 1 — GROUP
    # ------------------------------
    with tabs[0]:
        group = state.get("group")
        if not group:
            st.info("Group stage not started.")
        else:
            st.subheader("Group Stage Standings")
            standings = compute_group_standings(state)

            for pool in group.get("pools", []):
                pool_name = pool["name"]
                st.markdown(f"### {pool_name}")

                tbl = standings.get(pool_name, [])
                if not tbl:
                    st.write("No matches yet.")
                    continue

                qualifiers = pool.get("qualifiers", 1)

                # display table
                for rank, (mp, bp, tid) in enumerate(tbl, start=1):
                    line = f"{rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}"
                    if rank == qualifiers:
                        st.write(line)
                        st.markdown("---")
                    else:
                        st.write(line)

    # ------------------------------
    # TAB 2 — SWISS
    # ------------------------------
    with tabs[1]:
        swiss = state.get("swiss")
        if not swiss:
            st.info("Swiss stage not started.")
        else:
            st.subheader("Swiss Standings")

            finalized = swiss.get("finalized", False)
            hard_locked = swiss.get("hard_locked", False)

            mode_options = ["Live", "End-of-Round"]
            default_mode = "End-of-Round" if (finalized or hard_locked) else "Live"
            mode = st.radio("Display:", mode_options, index=mode_options.index(default_mode), horizontal=True)

            if mode == "Live":
                tbl = compute_swiss_standings_live(state)
            else:
                tbl = compute_swiss_standings_end_of_round(state)

            if not tbl:
                st.write("No Swiss standings available yet.")
            else:
                st.write("**Rank | Team | MP | BP | TB1 (Buchholz)**")
                for rank, (mp, bp, buch, tid) in enumerate(tbl, start=1):
                    name = state["teams"][tid]["name"]
                    st.write(f"{rank}. {name} — MP={mp}, BP={bp}, TB1={buch}")

            if finalized and not hard_locked:
                st.success("Soft Finalized — no changes expected.")
            if hard_locked:
                st.error("Tournament Hard Locked — read only.")

        # ------------------------------
    # TAB 3 — INDIVIDUAL
    # ------------------------------
    with tabs[2]:
        st.subheader("Individual Player Statistics")

        players = state.get("players", {})
        teams = state.get("teams", {})

        if not players or not teams:
            st.info("No player data available.")
            return

        subt = st.tabs(["Group Stats", "Swiss Stats", "Combined"])

        # ---------------------------------
        # Utility: derive stats from matches
        # ---------------------------------
        def compute_phase_stats(phase_key):
            stats = {}  # pid -> dict

            # GROUP stats
            if phase_key in ("group", "total"):
                group = state.get("group")
                if group:
                    for pool in group.get("pools", []):
                        for rnd in pool.get("rounds", []):
                            for match in rnd.get("matches", []):
                                if "bye" in match or match.get("status") != "done":
                                    continue
                                wline = match.get("lineup1")
                                bline = match.get("lineup2")
                                if not wline or not bline:
                                    continue

                                for board, r in enumerate(match.get("board_results", [])):
                                    wp = wline[board]
                                    bp = bline[board]

                                    for pid in (wp, bp):
                                        if pid not in stats:
                                            stats[pid] = dict(
                                                played=0, w=0, d=0, l=0, score=0, boards=set()
                                            )

                                    stats[wp]["boards"].add(board+1)
                                    stats[bp]["boards"].add(board+1)
                                    stats[wp]["played"] += 1
                                    stats[bp]["played"] += 1

                                    if r == 1:
                                        stats[wp]["w"] += 1
                                        stats[bp]["l"] += 1
                                        stats[wp]["score"] += 1
                                    elif r == 0.5:
                                        stats[wp]["d"] += 1
                                        stats[bp]["d"] += 1
                                        stats[wp]["score"] += 0.5
                                        stats[bp]["score"] += 0.5
                                    else:
                                        stats[wp]["l"] += 1
                                        stats[bp]["w"] += 1
                                        stats[bp]["score"] += 1

            # SWISS stats
            if phase_key in ("swiss", "total"):
                swiss = state.get("swiss")
                if swiss:
                    for rnd in swiss.get("rounds", []):
                        for match in rnd.get("matches", []):
                            if "bye" in match or match.get("status") != "done":
                                continue
                            wline = match.get("lineup1")
                            bline = match.get("lineup2")
                            if not wline or not bline:
                                continue

                            for board, r in enumerate(match.get("board_results", [])):
                                wp = wline[board]
                                bp = bline[board]

                                for pid in (wp, bp):
                                    if pid not in stats:
                                        stats[pid] = dict(
                                            played=0, w=0, d=0, l=0, score=0, boards=set()
                                        )

                                stats[wp]["boards"].add(board+1)
                                stats[bp]["boards"].add(board+1)
                                stats[wp]["played"] += 1
                                stats[bp]["played"] += 1

                                if r == 1:
                                    stats[wp]["w"] += 1
                                    stats[bp]["l"] += 1
                                    stats[wp]["score"] += 1
                                elif r == 0.5:
                                    stats[wp]["d"] += 1
                                    stats[bp]["d"] += 1
                                    stats[wp]["score"] += 0.5
                                    stats[bp]["score"] += 0.5
                                else:
                                    stats[wp]["l"] += 1
                                    stats[bp]["w"] += 1
                                    stats[bp]["score"] += 1

            return stats

        # ---------------------------------
        # Renderer
        # ---------------------------------
        def render_stats(phase_key):
            stats = compute_phase_stats(phase_key)
            if not stats:
                st.write("No data yet.")
                return

            rows = []
            for pid, d in stats.items():
                team_name = ""
                for tid, t in teams.items():
                    if pid in t["players"]:
                        team_name = t["name"]
                        break

                rows.append({
                    "Player": players[pid]["name"],
                    "Team": team_name,
                    "Played": d["played"],
                    "W": d["w"],
                    "D": d["d"],
                    "L": d["l"],
                    "Score": d["score"],
                    "Boards": ", ".join(map(str, sorted(d["boards"])))
                })

            rows.sort(key=lambda r: (-r["Score"], r["Player"]))
            st.dataframe(rows, use_container_width=True)

        # ---------------------------------
        # Subtabs
        # ---------------------------------
        with subt[0]:
            st.write("Scores from Group Stage only")
            render_stats("group")

        with subt[1]:
            st.write("Scores from Swiss Stage only")
            render_stats("swiss")

        with subt[2]:
            st.write("Combined Scores")
            render_stats("total")
