import streamlit as st
import json
import random
import string
from pathlib import Path
from datetime import datetime


DATA_DIR = Path("data/tournaments/active")


# -------------------------------------------
# Helpers for ID / State Load / Save
# -------------------------------------------

def load_state(slug):
    path = DATA_DIR / slug / "state.json"
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_state(slug, state):
    path = DATA_DIR / slug / "state.json"
    state["updated"] = datetime.now().isoformat(timespec="seconds")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def gen_player_id():
    token = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    return f"p_{token}"


# -------------------------------------------
# Computation Helpers
# -------------------------------------------

def compute_team_avg(starters, players):
    # unrated treated as 1400 for computation
    rating_values = []
    for pid in starters:
        r = players[pid].get("rating")
        if r is None:
            rating_values.append(1400)
        else:
            rating_values.append(r)
    if len(rating_values) == 0:
        return None
    return int(sum(rating_values) / len(rating_values))  # integer avg


def player_display(players, pid):
    p = players[pid]
    name = p["name"]
    rating = p.get("rating")
    if rating is None:
        return name
    else:
        # display as name (rating)
        if float(rating).is_integer():
            rating = int(rating)
        return f"{name} ({rating})"


def sorted_roster(team, players):
    starters = team.get("starters", [])
    subs = team.get("subs", [])
    # everything else = unassigned
    assigned = set(starters) | set(subs)
    unassigned = [pid for pid in team["players"] if pid not in assigned]

    # sort starters by board order (implicit order)
    starters_sorted = starters[:]

    # sort subs by rating desc then name
    subs_sorted = sorted(
        subs,
        key=lambda pid: (players[pid]["rating"] or 1400, players[pid]["name"]),
        reverse=True
    )

    # sort unassigned by name asc
    unassigned_sorted = sorted(unassigned, key=lambda pid: players[pid]["name"])

    return starters_sorted, subs_sorted, unassigned_sorted


# -------------------------------------------
# UI Rendering
# -------------------------------------------

def render(slug):
    if slug is None:
        st.info("No active tournament selected. Go to Tournaments page.")
        return

    state = load_state(slug)
    if state is None:
        st.error("Cannot load tournament")
        return

    teams = state["teams"]
    players = state["players"]
    stage = state["stage"]

    # determine if locked (post group start)
    locked = stage != "group"  # basic rule; we can refine later for override per-round

    st.title("Teams & Players")

    # -------------------------------------------
    # Sidebar: Team List + Add Team
    # -------------------------------------------

    st.sidebar.header("Teams")
    team_names = [(tid, teams[tid]["name"]) for tid in teams]
    selected_team_id = None

    for tid, name in team_names:
        if st.sidebar.button(name, key=f"team_{tid}"):
            st.session_state["selected_team"] = tid

    # button to add team
    with st.sidebar.expander("Add Team"):
        new_team_name = st.text_input("Team name", key="add_team_name")
        if st.button("Add", key="add_team_btn"):
            if not new_team_name.strip():
                st.warning("Team name cannot be empty.")
            elif any(t["name"] == new_team_name for t in teams.values()):
                st.warning("Team name must be unique.")
            else:
                tid = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
                teams[tid] = {
                    "name": new_team_name.strip(),
                    "players": [],
                    "starters": [],
                    "subs": [],
                    "base_board_order": []
                }
                save_state(slug, state)
                st.session_state["selected_team"] = tid
                st.rerun()

    # select currently active team
    selected_team_id = st.session_state.get("selected_team")
    if not selected_team_id or selected_team_id not in teams:
        if teams:
            # default pick first
            selected_team_id = list(teams.keys())[0]
            st.session_state["selected_team"] = selected_team_id
        else:
            st.info("No teams yet. Add a team.")
            return

    team = teams[selected_team_id]

    # -------------------------------------------
    # Main Panel for Selected Team
    # -------------------------------------------

    st.subheader(f"Team: {team['name']}")

    # rename team
    with st.expander("Rename Team"):
        new_name = st.text_input("New name", value=team["name"], key=f"rename_{selected_team_id}")
        if st.button("Rename", key=f"rename_btn_{selected_team_id}"):
            if not new_name.strip():
                st.warning("Name cannot be empty.")
            elif any(tid != selected_team_id and t["name"] == new_name for tid, t in teams.items()):
                st.warning("Team name must be unique.")
            else:
                team["name"] = new_name.strip()
                save_state(slug, state)
                st.success("Team renamed!")
                st.rerun()

    # delete team
    with st.expander("Delete Team"):
        if st.button("Delete", key=f"delete_team_{selected_team_id}"):
            # remove players too
            for pid in team["players"]:
                players.pop(pid, None)
            teams.pop(selected_team_id, None)
            save_state(slug, state)
            st.session_state.pop("selected_team", None)
            st.rerun()

    # compute team avg
    starters = team.get("starters", [])
    avg_rating = compute_team_avg(starters, players) if starters else None
    if avg_rating is not None:
        st.write(f"**Avg Rating:** {avg_rating}")

    # -------------------------------------------
    # Player List
    # -------------------------------------------

    starters_sorted, subs_sorted, unassigned_sorted = sorted_roster(team, players)

    st.markdown("### Roster")

    # display starters
    st.write("**Starters (Board Order)**")
    if starters_sorted:
        for i, pid in enumerate(starters_sorted, start=1):
            st.write(f"Board {i}: {player_display(players, pid)}")
    else:
        st.write("_No starters assigned yet_")

    # display subs
    st.write("**Substitutes**")
    if subs_sorted:
        for pid in subs_sorted:
            st.write(f"{player_display(players, pid)}")
    else:
        st.write("_No substitutes_")

    # display unassigned
    if unassigned_sorted:
        st.write("**Unassigned**")
        for pid in unassigned_sorted:
            st.write(player_display(players, pid))

    # -------------------------------------------
    # Add Player
    # -------------------------------------------

    st.markdown("### Add Player")
    col1, col2 = st.columns(2)
    with col1:
        pname = st.text_input("Name", key="player_name")
    with col2:
        rating_str = st.text_input("Rating (optional)", key="player_rating")

    if st.button("Add Player"):
        if not pname.strip():
            st.warning("Player name cannot be empty.")
        elif any(players[pid]["name"] == pname and players[pid]["team_id"] == selected_team_id for pid in players):
            st.warning("Player name must be unique within team.")
        else:
            pid = gen_player_id()
            try:
                rating = float(rating_str) if rating_str.strip() else None
            except:
                st.warning("Invalid rating. Must be numeric.")
                rating = None

            players[pid] = {
                "name": pname.strip(),
                "rating": rating,
                "team_id": selected_team_id
            }
            team["players"].append(pid)
            save_state(slug, state)
            st.success(f"Player {pname} added!")
            st.rerun()

    # -------------------------------------------
    # Assign Starters & Subs (Manual)
    # -------------------------------------------

    st.markdown("### Assign Roles")

    # Initialize session state for this team if not present
    session_key_starters = f"team_starters_{selected_team_id}"
    session_key_subs = f"team_subs_{selected_team_id}"
    
    if session_key_starters not in st.session_state:
        st.session_state[session_key_starters] = starters_sorted.copy() if starters_sorted else [None, None, None, None]
    if session_key_subs not in st.session_state:
        st.session_state[session_key_subs] = subs_sorted.copy() if subs_sorted else []

    # starter assignment
    st.write("**Starters (Board Order)**")
    all_pids = team["players"][:]
    player_options = {player_display(players, pid): pid for pid in all_pids}

    new_starters = []
    for board in range(4):
        current = st.session_state[session_key_starters][board] if board < len(st.session_state[session_key_starters]) else None
        label = f"Board {board+1}"
        displayed_current = player_display(players, current) if current else None
        selection = st.selectbox(label,
                                 [""] + list(player_options.keys()),
                                 index=(list(player_options.keys()).index(displayed_current) + 1 if displayed_current in player_options else 0),
                                 key=f"starter_{board}")
        pid = player_options.get(selection)
        new_starters.append(pid)
        st.session_state[session_key_starters][board] = pid

    # sub assignment
    st.write("**Substitutes** (max 2)")
    remaining = [pid for pid in all_pids if pid not in new_starters]
    sub_options = {player_display(players, pid): pid for pid in remaining}

    new_subs = []
    for si in range(2):
        current = st.session_state[session_key_subs][si] if si < len(st.session_state[session_key_subs]) else None
        displayed = player_display(players, current) if current else None
        selection = st.selectbox(f"Sub {si+1}",
                                 [""] + list(sub_options.keys()),
                                 index=(list(sub_options.keys()).index(displayed) + 1 if displayed in sub_options else 0),
                                 key=f"sub_{si}")
        pid = sub_options.get(selection)
        if pid:
            new_subs.append(pid)
    
    st.session_state[session_key_subs] = new_subs

    # -------------------------------------------
    # Base Board Order Section
    # -------------------------------------------
    
    st.markdown("---")
    st.markdown("### Base Board Order")
    st.caption("This is the default lineup used when starting matches. It will be shown when you click 'Reset to Base Order' during lineup selection.")
    
    # Get current base board order or default to starters
    current_base_order = team.get("base_board_order", [])
    if not current_base_order and starters_sorted:
        current_base_order = starters_sorted[:4]
    
    # Initialize session state for base board order
    session_key_base = f"team_base_order_{selected_team_id}"
    if session_key_base not in st.session_state:
        st.session_state[session_key_base] = current_base_order.copy() if current_base_order else [None, None, None, None]
    
    st.write("**Set Base Board Order:**")
    base_board_order = []
    
    # Only allow selection from starters
    starter_pids = [p for p in new_starters if p is not None]
    base_options = {player_display(players, pid): pid for pid in starter_pids}
    
    for board in range(4):
        current = st.session_state[session_key_base][board] if board < len(st.session_state[session_key_base]) else None
        # Verify current is still a starter
        if current not in starter_pids:
            current = None
        
        label = f"Base Board {board+1}"
        displayed_current = player_display(players, current) if current else None
        selection = st.selectbox(label,
                                 [""] + list(base_options.keys()),
                                 index=(list(base_options.keys()).index(displayed_current) + 1 if displayed_current in base_options else 0),
                                 key=f"base_board_{board}")
        pid = base_options.get(selection)
        base_board_order.append(pid)
        st.session_state[session_key_base][board] = pid
    
    # Quick set button to copy from starters
    if st.button("Copy from Current Starters", key="copy_to_base"):
        st.session_state[session_key_base] = new_starters.copy()
        st.rerun()

    # -------------------------------------------
    # Validation + Save Button
    # -------------------------------------------
    
    st.markdown("---")
    
    # Validation messages
    valid = True
    validation_messages = []
    
    if None in new_starters:
        validation_messages.append("⚠️ You must assign exactly 4 starters.")
        valid = False
    elif len(set(new_starters)) != len(new_starters):
        validation_messages.append("⚠️ Duplicate starters not allowed.")
        valid = False
    
    if len(set(new_subs)) != len(new_subs):
        validation_messages.append("⚠️ Duplicate subs not allowed.")
        valid = False
    
    # Check base board order
    if None in base_board_order:
        validation_messages.append("⚠️ Base board order must have all 4 boards filled.")
        valid = False
    elif len(set(base_board_order)) != len(base_board_order):
        validation_messages.append("⚠️ Duplicate players in base board order not allowed.")
        valid = False
    
    # Display validation messages
    for msg in validation_messages:
        st.warning(msg)
    
    # Save button - prominent and always visible
    if valid:
        st.success("✅ All assignments are valid!")
    
    col_save, col_space = st.columns([1, 3])
    with col_save:
        if st.button("Save Team Configuration", disabled=not valid):
            # Save all data
            team["starters"] = new_starters
            team["subs"] = new_subs
            team["base_board_order"] = base_board_order
            save_state(slug, state)
            
            # Clear session state for this team
            st.session_state.pop(session_key_starters, None)
            st.session_state.pop(session_key_subs, None)
            st.session_state.pop(session_key_base, None)
            
            st.success("✅ Team configuration saved successfully!")
            st.rerun()
    
    if not valid:
        st.info("Fix the validation errors above to enable saving.")