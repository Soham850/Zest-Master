import streamlit as st
import json
from pathlib import Path
from datetime import datetime

DATA_DIR = Path("data/tournaments/active")

def load_state(slug):
    path = DATA_DIR / slug / "state.json"
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_state(slug, state):
    path = DATA_DIR / slug / "state.json"
    state["updated"] = datetime.now().isoformat(timespec="seconds")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)

def compute_team_avg_rating(team_id, state):
    """Calculate average rating for a team (unrated = 1400)."""
    team = state["teams"][team_id]
    players = state["players"]
    
    total = 0
    count = 0
    for pid in team["players"]:
        rating = players[pid].get("rating")
        if rating is None:
            total += 1400
        else:
            total += rating
        count += 1
    
    return total / count if count > 0 else 1400

def get_qualifiers_from_group(state):
    """Extract qualified teams from group stage based on pool standings."""
    if "group" not in state:
        return []
    
    group = state["group"]
    pools = group.get("pools", [])
    
    qualifiers = []
    for pool in pools:
        # Calculate final standings for this pool
        standings = []
        for tid in pool["team_ids"]:
            mp = bp = 0
            for rnd in pool["rounds"]:
                for match in rnd["matches"]:
                    if "bye" in match:
                        continue
                    if match.get("status") != "done":
                        continue
                    if match["white"] == tid:
                        mp += match["mp1"]
                        bp += match["bp1"]
                    elif match["black"] == tid:
                        mp += match["mp2"]
                        bp += match["bp2"]
            standings.append((mp, bp, tid))
        
        standings.sort(reverse=True)
        
        # Get top N qualifiers from this pool
        num_qualifiers = pool.get("qualifiers", 1)
        for rank in range(min(num_qualifiers, len(standings))):
            qualifiers.append(standings[rank][2])
    
    return qualifiers

def check_group_complete(state):
    """Check if all group stage pools and rounds are locked."""
    if "group" not in state:
        return False, "Group stage not started"
    
    group = state["group"]
    pools = group.get("pools", [])
    
    if not pools:
        return False, "No pools in group stage"
    
    for pool in pools:
        rounds = pool.get("rounds", [])
        locked_rounds = pool.get("locked_rounds", {})
        
        for rnd in rounds:
            round_num = rnd["round"]
            if str(round_num) not in locked_rounds:
                return False, f"Pool {pool['name']} Round {round_num} not locked"
    
    return True, "Group stage complete"

def calculate_buchholz(team_id, swiss_rounds):
    """Calculate Buchholz tiebreak (sum of opponents' MP)."""
    opponents = []
    
    for rnd in swiss_rounds:
        for match in rnd.get("matches", []):
            if "bye" in match:
                continue
            if match["white"] == team_id:
                opponents.append(match["black"])
            elif match["black"] == team_id:
                opponents.append(match["white"])
    
    # Calculate total MP for each opponent
    buchholz = 0
    for opp_id in opponents:
        opp_mp = 0
        for rnd in swiss_rounds:
            for match in rnd.get("matches", []):
                if "bye" in match:
                    continue
                if match.get("status") != "done":
                    continue
                if match["white"] == opp_id:
                    opp_mp += match["mp1"]
                elif match["black"] == opp_id:
                    opp_mp += match["mp2"]
        buchholz += opp_mp
    
    return buchholz

def compute_swiss_standings(swiss_teams, swiss_rounds, update_mode="live"):
    """
    Compute Swiss standings.
    update_mode: 'live' = update after each match, 'end_of_round' = only locked rounds
    """
    standings = []
    
    for tid in swiss_teams:
        mp = bp = 0
        
        for rnd in swiss_rounds:
            # In end_of_round mode, skip unlocked rounds
            if update_mode == "end_of_round" and not rnd.get("locked", False):
                continue
            
            for match in rnd.get("matches", []):
                if "bye" in match:
                    if match["bye"] == tid:
                        mp += 1  # Bye = 1 MP
                    continue
                
                if match.get("status") != "done":
                    continue
                
                if match["white"] == tid:
                    mp += match["mp1"]
                    bp += match["bp1"]
                elif match["black"] == tid:
                    mp += match["mp2"]
                    bp += match["bp2"]
        
        buchholz = calculate_buchholz(tid, swiss_rounds)
        standings.append((mp, bp, buchholz, tid))
    
    standings.sort(reverse=True)
    return standings

def render(slug):
    if slug is None:
        st.info("No active tournament selected.")
        return
    
    state = load_state(slug)
    if state is None:
        st.error("Cannot load tournament.")
        return
    
    st.title("Swiss Stage")
    
    # Check if group stage is complete
    group_complete, msg = check_group_complete(state)
    
    if not group_complete:
        st.warning(f"⚠️ Cannot start Swiss Stage: {msg}")
        st.info("Complete and lock all group stage rounds first.")
        return
    
    # Initialize Swiss if not started
    if "swiss" not in state or state.get("stage") not in ["swiss_setup", "swiss_running", "swiss_finalized"]:
        st.subheader("Start Swiss Stage")
        
        # Get qualifiers
        qualifiers = get_qualifiers_from_group(state)
        
        if not qualifiers:
            st.error("No teams qualified from group stage.")
            return
        
        st.write(f"**{len(qualifiers)} teams qualified from group stage:**")
        for tid in qualifiers:
            avg_rating = compute_team_avg_rating(tid, state)
            st.write(f"- {state['teams'][tid]['name']} (Avg: {int(avg_rating)})")
        
        st.markdown("---")
        
        num_rounds = st.number_input(
            "Initial number of Swiss rounds",
            min_value=1,
            max_value=15,
            value=5,
            key="swiss_rounds_input"
        )
        
        if st.button("Initialize Swiss Stage"):
            # Seed teams by average rating
            seeded = []
            for tid in qualifiers:
                avg = compute_team_avg_rating(tid, state)
                seeded.append((avg, tid))
            seeded.sort(reverse=True)
            
            swiss_teams = [tid for _, tid in seeded]
            
            # Initialize Swiss structure
            state["swiss"] = {
                "teams": swiss_teams,
                "rounds": [],
                "current_round": 0,
                "finalized": False,
                "hard_locked": False,
                "standings_mode": "live"
            }
            
            # Create empty rounds
            for r in range(num_rounds):
                state["swiss"]["rounds"].append({
                    "round": r + 1,
                    "matches": [],
                    "locked": False
                })
            
            state["stage"] = "swiss_setup"
            save_state(slug, state)
            st.success("Swiss Stage initialized!")
            st.rerun()

    swiss = state.get("swiss")
    
    # Safety check
    if not swiss:
        st.info("Swiss stage data not found. Please initialize Swiss stage first.")
        return
    
    # Swiss Stage UI
    swiss = state["swiss"]
    swiss_teams = swiss["teams"]
    swiss_rounds = swiss["rounds"]
    current_round = swiss.get("current_round", 0)
    finalized = swiss.get("finalized", False)
    hard_locked = swiss.get("hard_locked", False)
    
    # Show seed order
    if current_round == 0 and state.get("stage") == "swiss_setup":
        st.subheader("Seeding (by Average Rating)")
        for rank, tid in enumerate(swiss_teams, start=1):
            avg = compute_team_avg_rating(tid, state)
            st.write(f"{rank}. {state['teams'][tid]['name']} — Avg: {int(avg)}")
        
        st.markdown("---")
        
        if st.button("Start Swiss Round 1"):
            swiss["current_round"] = 1
            state["stage"] = "swiss_running"
            save_state(slug, state)
            st.rerun()
        
        return
    
    # Main Swiss execution
    if state.get("stage") in ["swiss_running", "swiss_finalized"]:
        total_rounds = len(swiss_rounds)
        
        # Round navigation
        st.subheader(f"Swiss Stage — Round {current_round}/{total_rounds}")
        
        col1, col2, col3 = st.columns([1, 1, 2])
        with col1:
            if st.button("← Prev", disabled=(current_round <= 1 or hard_locked)):
                swiss["current_round"] = current_round - 1
                save_state(slug, state)
                st.rerun()
        with col2:
            if st.button("Next →", disabled=(current_round >= total_rounds or hard_locked)):
                swiss["current_round"] = current_round + 1
                save_state(slug, state)
                st.rerun()
        
        if current_round > 0 and current_round <= total_rounds:
            rnd = swiss_rounds[current_round - 1]
            matches = rnd.get("matches", [])
            is_locked = rnd.get("locked", False)
            
            st.markdown("---")
            
            # Pairing input (if not locked)
            if not is_locked and not hard_locked:
                st.subheader("Enter Pairings")
                st.caption("Use external Swiss Perfect to generate pairings, then input them here.")
                
                num_matches = st.number_input(
                    "Number of pairings",
                    min_value=0,
                    max_value=len(swiss_teams) // 2 + 1,
                    value=len(matches) if matches else len(swiss_teams) // 2,
                    key=f"num_matches_r{current_round}"
                )
                
                # Build match list
                new_matches = []
                team_options = [""] + [state["teams"][tid]["name"] for tid in swiss_teams]
                team_lookup = {state["teams"][tid]["name"]: tid for tid in swiss_teams}
                
                for mi in range(num_matches):
                    st.write(f"**Match {mi + 1}**")
                    cols = st.columns([2, 2, 1])
                    
                    existing_match = matches[mi] if mi < len(matches) else None
                    
                    # Handle bye
                    if existing_match and "bye" in existing_match:
                        bye_tid = existing_match["bye"]
                        default_bye = state["teams"][bye_tid]["name"]
                    else:
                        default_bye = ""
                    
                    with cols[0]:
                        white_name = st.selectbox(
                            "White",
                            options=team_options,
                            index=team_options.index(state["teams"][existing_match["white"]]["name"]) if existing_match and "white" in existing_match else 0,
                            key=f"white_r{current_round}_m{mi}"
                        )
                    
                    with cols[1]:
                        black_name = st.selectbox(
                            "Black",
                            options=team_options,
                            index=team_options.index(state["teams"][existing_match["black"]]["name"]) if existing_match and "black" in existing_match else 0,
                            key=f"black_r{current_round}_m{mi}"
                        )
                    
                    with cols[2]:
                        is_bye = st.checkbox("Bye", value=(existing_match and "bye" in existing_match), key=f"bye_r{current_round}_m{mi}")
                    
                    if is_bye:
                        bye_team = st.selectbox(
                            "Team with Bye",
                            options=team_options,
                            index=team_options.index(default_bye) if default_bye in team_options else 0,
                            key=f"bye_team_r{current_round}_m{mi}"
                        )
                        if bye_team:
                            new_matches.append({"bye": team_lookup[bye_team]})
                    else:
                        if white_name and black_name:
                            match_data = {
                                "white": team_lookup[white_name],
                                "black": team_lookup[black_name],
                                "lineup1": None,
                                "lineup2": None,
                                "board_results": [None, None, None, None],
                                "bp1": 0,
                                "bp2": 0,
                                "mp1": 0,
                                "mp2": 0,
                                "status": "pending"
                            }
                            new_matches.append(match_data)
                
                if st.button("Save Pairings", key=f"save_pairings_r{current_round}"):
                    rnd["matches"] = new_matches
                    save_state(slug, state)
                    st.success("Pairings saved!")
                    st.rerun()
                
                st.markdown("---")
            
            # Match execution
            st.subheader("Matches")
            
            for mi, match in enumerate(matches):
                if "bye" in match:
                    tid = match["bye"]
                    st.info(f"{state['teams'][tid]['name']} has a bye (1 MP)")
                    continue
                
                t1_id = match['white']
                t2_id = match['black']
                t1 = state['teams'][t1_id]['name']
                t2 = state['teams'][t2_id]['name']
                
                st.write(f"**{t1} (White) — {t2} (Black)**")
                
                # Lineup confirmation
                if match.get("lineup1") is None or match.get("lineup2") is None:
                    if is_locked or hard_locked:
                        st.warning("Round is locked. Cannot set lineups.")
                    else:
                        with st.expander("Set Lineups", expanded=True):
                            session_key_t1 = f"swiss_lineup1_{current_round}_{mi}"
                            session_key_t2 = f"swiss_lineup2_{current_round}_{mi}"
                            
                            # Team 1 (White)
                            st.write(f"**{t1} (White) Lineup:**")
                            t1_players = state['teams'][t1_id]['players']
                            t1_player_names = {pid: state['players'][pid]['name'] for pid in t1_players}
                            
                            base_order_t1 = state['teams'][t1_id].get('base_board_order', [])
                            if not base_order_t1 or len(base_order_t1) < 4:
                                base_order_t1 = t1_players[:4]
                            else:
                                base_order_t1 = base_order_t1[:4]
                            
                            if session_key_t1 not in st.session_state:
                                st.session_state[session_key_t1] = base_order_t1.copy()
                            
                            st.caption("Base Board Order:")
                            for i, pid in enumerate(base_order_t1):
                                st.caption(f"  Board {i+1}: {t1_player_names[pid]}")
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                if st.button("Reset to Base Order", key=f"swiss_base1_{current_round}_{mi}"):
                                    st.session_state[session_key_t1] = base_order_t1.copy()
                                    st.rerun()
                            with col2:
                                if st.button("Make Substitution", key=f"swiss_sub1_{current_round}_{mi}"):
                                    st.session_state[f"swiss_show_sub1_{current_round}_{mi}"] = True
                                    st.rerun()
                            
                            if st.session_state.get(f"swiss_show_sub1_{current_round}_{mi}", False):
                                current_lineup_t1 = st.session_state[session_key_t1]
                                
                                st.write("**Select player to bench:**")
                                benched_t1 = st.selectbox(
                                    "Bench",
                                    options=current_lineup_t1,
                                    format_func=lambda x: t1_player_names[x],
                                    key=f"swiss_bench1_{current_round}_{mi}"
                                )
                                
                                available_subs_t1 = [p for p in t1_players if p not in current_lineup_t1]
                                
                                if available_subs_t1:
                                    st.write("**Select substitute:**")
                                    sub_t1 = st.selectbox(
                                        "Substitute",
                                        options=available_subs_t1,
                                        format_func=lambda x: t1_player_names[x],
                                        key=f"swiss_subplayer1_{current_round}_{mi}"
                                    )
                                    
                                    col_apply, col_cancel = st.columns(2)
                                    with col_apply:
                                        if st.button("Apply FIDE Ladder", key=f"swiss_apply1_{current_round}_{mi}"):
                                            new_lineup = current_lineup_t1.copy()
                                            benched_idx = new_lineup.index(benched_t1)
                                            new_lineup.pop(benched_idx)
                                            new_lineup.append(sub_t1)
                                            
                                            st.session_state[session_key_t1] = new_lineup
                                            st.session_state[f"swiss_show_sub1_{current_round}_{mi}"] = False
                                            st.success(f"✓ {t1_player_names[sub_t1]} substitutes for {t1_player_names[benched_t1]}")
                                            st.rerun()
                                    with col_cancel:
                                        if st.button("Cancel", key=f"swiss_cancel1_{current_round}_{mi}"):
                                            st.session_state[f"swiss_show_sub1_{current_round}_{mi}"] = False
                                            st.rerun()
                                else:
                                    st.warning("No available substitutes")
                                    if st.button("Cancel", key=f"swiss_cancel1_nosub_{current_round}_{mi}"):
                                        st.session_state[f"swiss_show_sub1_{current_round}_{mi}"] = False
                                        st.rerun()
                            
                            current_lineup_t1 = st.session_state[session_key_t1]
                            st.write("**Current Lineup:**")
                            for i, pid in enumerate(current_lineup_t1):
                                st.write(f"Board {i+1}: {t1_player_names[pid]}")
                            
                            st.markdown("---")
                            
                            # Team 2 (Black)
                            st.write(f"**{t2} (Black) Lineup:**")
                            t2_players = state['teams'][t2_id]['players']
                            t2_player_names = {pid: state['players'][pid]['name'] for pid in t2_players}
                            
                            base_order_t2 = state['teams'][t2_id].get('base_board_order', [])
                            if not base_order_t2 or len(base_order_t2) < 4:
                                base_order_t2 = t2_players[:4]
                            else:
                                base_order_t2 = base_order_t2[:4]
                            
                            if session_key_t2 not in st.session_state:
                                st.session_state[session_key_t2] = base_order_t2.copy()
                            
                            st.caption("Base Board Order:")
                            for i, pid in enumerate(base_order_t2):
                                st.caption(f"  Board {i+1}: {t2_player_names[pid]}")
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                if st.button("Reset to Base Order", key=f"swiss_base2_{current_round}_{mi}"):
                                    st.session_state[session_key_t2] = base_order_t2.copy()
                                    st.rerun()
                            with col2:
                                if st.button("Make Substitution", key=f"swiss_sub2_{current_round}_{mi}"):
                                    st.session_state[f"swiss_show_sub2_{current_round}_{mi}"] = True
                                    st.rerun()
                            
                            if st.session_state.get(f"swiss_show_sub2_{current_round}_{mi}", False):
                                current_lineup_t2 = st.session_state[session_key_t2]
                                
                                st.write("**Select player to bench:**")
                                benched_t2 = st.selectbox(
                                    "Bench",
                                    options=current_lineup_t2,
                                    format_func=lambda x: t2_player_names[x],
                                    key=f"swiss_bench2_{current_round}_{mi}"
                                )
                                
                                available_subs_t2 = [p for p in t2_players if p not in current_lineup_t2]
                                
                                if available_subs_t2:
                                    st.write("**Select substitute:**")
                                    sub_t2 = st.selectbox(
                                        "Substitute",
                                        options=available_subs_t2,
                                        format_func=lambda x: t2_player_names[x],
                                        key=f"swiss_subplayer2_{current_round}_{mi}"
                                    )
                                    
                                    col_apply, col_cancel = st.columns(2)
                                    with col_apply:
                                        if st.button("Apply FIDE Ladder", key=f"swiss_apply2_{current_round}_{mi}"):
                                            new_lineup = current_lineup_t2.copy()
                                            benched_idx = new_lineup.index(benched_t2)
                                            new_lineup.pop(benched_idx)
                                            new_lineup.append(sub_t2)
                                            
                                            st.session_state[session_key_t2] = new_lineup
                                            st.session_state[f"swiss_show_sub2_{current_round}_{mi}"] = False
                                            st.success(f"✓ {t2_player_names[sub_t2]} substitutes for {t2_player_names[benched_t2]}")
                                            st.rerun()
                                    with col_cancel:
                                        if st.button("Cancel", key=f"swiss_cancel2_{current_round}_{mi}"):
                                            st.session_state[f"swiss_show_sub2_{current_round}_{mi}"] = False
                                            st.rerun()
                                else:
                                    st.warning("No available substitutes")
                                    if st.button("Cancel", key=f"swiss_cancel2_nosub_{current_round}_{mi}"):
                                        st.session_state[f"swiss_show_sub2_{current_round}_{mi}"] = False
                                        st.rerun()
                            
                            current_lineup_t2 = st.session_state[session_key_t2]
                            st.write("**Current Lineup:**")
                            for i, pid in enumerate(current_lineup_t2):
                                st.write(f"Board {i+1}: {t2_player_names[pid]}")
                            
                            st.markdown("---")
                            
                            if st.button(f"Confirm Lineups", key=f"swiss_lu_confirm_{current_round}_{mi}"):
                                match["lineup1"] = st.session_state[session_key_t1]
                                match["lineup2"] = st.session_state[session_key_t2]
                                
                                save_state(slug, state)
                                
                                st.session_state.pop(session_key_t1, None)
                                st.session_state.pop(session_key_t2, None)
                                st.session_state.pop(f"swiss_show_sub1_{current_round}_{mi}", None)
                                st.session_state.pop(f"swiss_show_sub2_{current_round}_{mi}", None)
                                
                                st.success("✅ Lineups confirmed and saved!")
                                st.rerun()
                else:
                    # Display confirmed lineups
                    with st.expander("View/Edit Lineups"):
                        c1, c2 = st.columns(2)
                        
                        with c1:
                            st.markdown(f"**{t1} (White)**")
                            for board, pid in enumerate(match["lineup1"], start=1):
                                st.write(f"Board {board}: {state['players'][pid]['name']}")
                        
                        with c2:
                            st.markdown(f"**{t2} (Black)**")
                            for board, pid in enumerate(match["lineup2"], start=1):
                                st.write(f"Board {board}: {state['players'][pid]['name']}")
                        
                        st.markdown("---")
                        
                        if not is_locked and not hard_locked:
                            if st.button("Edit Lineups", key=f"swiss_edit_lu_{current_round}_{mi}"):
                                match["lineup1"] = None
                                match["lineup2"] = None
                                save_state(slug, state)
                                st.rerun()
                    
                    if not is_locked and not hard_locked:
                        # Hotkey input
                        hk = st.text_input("Hotkey (z=1-0, x=½-½, c=0-1)", value="",
                                          key=f"swiss_hk_{current_round}_{mi}", max_chars=1)
                        if hk:
                            for b in range(4):
                                if match["board_results"][b] is None:
                                    if hk.lower() == "z":
                                        match["board_results"][b] = 1
                                    elif hk.lower() == "x":
                                        match["board_results"][b] = 0.5
                                    elif hk.lower() == "c":
                                        match["board_results"][b] = 0
                            save_state(slug, state)
                            st.rerun()
                        
                        # Board result buttons
                        cols = st.columns(4)
                        for b in range(4):
                            r = match["board_results"][b]
                            with cols[b]:
                                wp_name = state['players'][match["lineup1"][b]]['name']
                                bp_name = state['players'][match["lineup2"][b]]['name']
                                st.caption(f"{wp_name} vs {bp_name}")
                                
                                if r is None:
                                    if st.button("1-0", key=f"swiss_w_{current_round}_{mi}_{b}"):
                                        match["board_results"][b] = 1
                                        save_state(slug, state)
                                        st.rerun()
                                    if st.button("½-½", key=f"swiss_d_{current_round}_{mi}_{b}"):
                                        match["board_results"][b] = 0.5
                                        save_state(slug, state)
                                        st.rerun()
                                    if st.button("0-1", key=f"swiss_l_{current_round}_{mi}_{b}"):
                                        match["board_results"][b] = 0
                                        save_state(slug, state)
                                        st.rerun()
                                else:
                                    st.success(f"Board {b+1}: {r}")
                                    if st.button("Reset", key=f"swiss_reset_{current_round}_{mi}_{b}"):
                                        match["board_results"][b] = None
                                        save_state(slug, state)
                                        st.rerun()
                        
                        # Scoring and stats update
                        if all(r is not None for r in match["board_results"]):
                            bp1 = sum(1 if r == 1 else 0.5 if r == 0.5 else 0 
                                     for r in match["board_results"])
                            bp2 = 4 - bp1
                            match["bp1"] = bp1
                            match["bp2"] = bp2
                            match["mp1"] = 1 if bp1 >= 2.5 else 0.5 if bp1 == 2 else 0
                            match["mp2"] = 1 if bp2 >= 2.5 else 0.5 if bp2 == 2 else 0
                            match["status"] = "done"
                            
                            # Update individual player stats
                            white_pids = match["lineup1"]
                            black_pids = match["lineup2"]
                            
                            if "player_stats" not in state:
                                state["player_stats"] = {}
                            
                            for b in range(4):
                                r = match["board_results"][b]
                                wp = white_pids[b]
                                bp = black_pids[b]
                                
                                pst = state["player_stats"]
                                
                                for pid in [wp, bp]:
                                    if pid not in pst:
                                        team_name = "Unknown"
                                        for tid in state["teams"]:
                                            if pid in state["teams"][tid]["players"]:
                                                team_name = state["teams"][tid]["name"]
                                                break
                                        
                                        pst[pid] = {
                                            "group": {
                                                "played": 0,
                                                "w": 0,
                                                "d": 0,
                                                "l": 0,
                                                "score": 0,
                                                "boards": [],
                                                "teams": team_name
                                            },
                                            "swiss": {
                                                "played": 0,
                                                "w": 0,
                                                "d": 0,
                                                "l": 0,
                                                "score": 0,
                                                "boards": [],
                                                "teams": team_name
                                            },
                                            "total": {
                                                "played": 0,
                                                "w": 0,
                                                "d": 0,
                                                "l": 0,
                                                "score": 0,
                                                "boards": []
                                            }
                                        }
                                
                                # Record board played
                                if (b + 1) not in pst[wp]["swiss"]["boards"]:
                                    pst[wp]["swiss"]["boards"].append(b + 1)
                                if (b + 1) not in pst[bp]["swiss"]["boards"]:
                                    pst[bp]["swiss"]["boards"].append(b + 1)
                                
                                # Assign score
                                if r == 1:
                                    pst[wp]["swiss"]["w"] += 1
                                    pst[bp]["swiss"]["l"] += 1
                                    pst[wp]["swiss"]["score"] += 1
                                elif r == 0.5:
                                    pst[wp]["swiss"]["d"] += 1
                                    pst[bp]["swiss"]["d"] += 1
                                    pst[wp]["swiss"]["score"] += 0.5
                                    pst[bp]["swiss"]["score"] += 0.5
                                else:
                                    pst[wp]["swiss"]["l"] += 1
                                    pst[bp]["swiss"]["w"] += 1
                                    pst[bp]["swiss"]["score"] += 1
                                
                                pst[wp]["swiss"]["played"] += 1
                                pst[bp]["swiss"]["played"] += 1
                            
                            # Update total stats
                            for pid in state["player_stats"]:
                                stt = state["player_stats"][pid]
                                stt["total"]["played"] = stt["group"]["played"] + stt["swiss"]["played"]
                                stt["total"]["w"] = stt["group"]["w"] + stt["swiss"]["w"]
                                stt["total"]["d"] = stt["group"]["d"] + stt["swiss"]["d"]
                                stt["total"]["l"] = stt["group"]["l"] + stt["swiss"]["l"]
                                stt["total"]["score"] = stt["group"]["score"] + stt["swiss"]["score"]
                                stt["total"]["boards"] = stt["group"]["boards"] + stt["swiss"]["boards"]
                            
                            save_state(slug, state)
                    else:
                        # Show results only
                        cols = st.columns(4)
                        for b in range(4):
                            r = match["board_results"][b]
                            with cols[b]:
                                wp_name = state['players'][match["lineup1"][b]]['name']
                                bp_name = state['players'][match["lineup2"][b]]['name']
                                st.caption(f"{wp_name} vs {bp_name}")
                                if r is not None:
                                    st.success(f"Board {b+1}: {r}")
                
                st.markdown("---")
            
            # Round confirmation
            round_done = all(
                match.get("status") == "done" or "bye" in match
                for match in matches
            )
            
            if not is_locked and not hard_locked:
                if round_done and matches:
                    if st.button("Confirm & Lock Round", key=f"swiss_lock_{current_round}"):
                        rnd["locked"] = True
                        save_state(slug, state)
                        st.success("Round locked!")
                        st.rerun()
                else:
                    st.info("Complete all matches to lock this round.")
            else:
                st.success("✅ Round Confirmed & Locked")
                
                if not hard_locked:
                    if st.button("Override Round (TD Only)", key=f"swiss_ovr_{current_round}"):
                        rnd["locked"] = False
                        
                        # Reset match data
                        for match in matches:
                            if "bye" not in match:
                                if match.get("lineup1") and match.get("lineup2"):
                                    white_pids = match["lineup1"]
                                    black_pids = match["lineup2"]
                                    
                                    for b in range(4):
                                        if match["board_results"][b] is not None:
                                            r = match["board_results"][b]
                                            wp = white_pids[b]
                                            bp = black_pids[b]
                                            pst = state["player_stats"]
                                            
                                            if r == 1:
                                                pst[wp]["swiss"]["w"] -= 1
                                                pst[bp]["swiss"]["l"] -= 1
                                                pst[wp]["swiss"]["score"] -= 1
                                            elif r == 0.5:
                                                pst[wp]["swiss"]["d"] -= 1
                                                pst[bp]["swiss"]["d"] -= 1
                                                pst[wp]["swiss"]["score"] -= 0.5
                                                pst[bp]["swiss"]["score"] -= 0.5
                                            else:
                                                pst[wp]["swiss"]["l"] -= 1
                                                pst[bp]["swiss"]["w"] -= 1
                                                pst[bp]["swiss"]["score"] -= 1
                                            
                                            pst[wp]["swiss"]["played"] -= 1
                                            pst[bp]["swiss"]["played"] -= 1
                                
                                match["status"] = "pending"
                                match["board_results"] = [None, None, None, None]
                                match["bp1"] = 0
                                match["bp2"] = 0
                                match["mp1"] = 0
                                match["mp2"] = 0
                        
                        # Update total stats
                        for pid in state["player_stats"]:
                            stt = state["player_stats"][pid]
                            stt["total"]["played"] = stt["group"]["played"] + stt["swiss"]["played"]
                            stt["total"]["w"] = stt["group"]["w"] + stt["swiss"]["w"]
                            stt["total"]["d"] = stt["group"]["d"] + stt["swiss"]["d"]
                            stt["total"]["l"] = stt["group"]["l"] + stt["swiss"]["l"]
                            stt["total"]["score"] = stt["group"]["score"] + stt["swiss"]["score"]
                            stt["total"]["boards"] = stt["group"]["boards"] + stt["swiss"]["boards"]
                        
                        save_state(slug, state)
                        st.warning("Round unlocked for editing by TD override.")
                        st.rerun()
        
        # Standings
        st.markdown("---")
        st.subheader("Swiss Standings")
        
        # Standings mode toggle
        if not hard_locked:
            mode = st.radio(
                "Update Mode",
                options=["live", "end_of_round"],
                format_func=lambda x: "Live (after each match)" if x == "live" else "End of Round (only locked rounds)",
                index=0 if swiss.get("standings_mode", "live") == "live" else 1,
                horizontal=True,
                key="swiss_standings_mode"
            )
            swiss["standings_mode"] = mode
            save_state(slug, state)
        else:
            mode = "end_of_round"
        
        standings = compute_swiss_standings(swiss_teams, swiss_rounds, mode)
        
        st.write("**Rank | Team | MP | BP | Buchholz**")
        for rank, (mp, bp, buchholz, tid) in enumerate(standings, start=1):
            st.write(f"{rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")
        
        # Add round button
        st.markdown("---")
        all_locked = all(r.get("locked", False) for r in swiss_rounds)
        
        if not finalized and not hard_locked and all_locked:
            if st.button("Add Another Round"):
                new_round_num = len(swiss_rounds) + 1
                swiss_rounds.append({
                    "round": new_round_num,
                    "matches": [],
                    "locked": False
                })
                swiss["current_round"] = new_round_num
                save_state(slug, state)
                st.success(f"Round {new_round_num} added!")
                st.rerun()
        
        # Finalization
        if not finalized and all_locked and not hard_locked:
            st.markdown("---")
            st.subheader("Tournament Finalization")
            
            if st.button("🏆 End Tournament (Soft Finalize)"):
                swiss["finalized"] = True
                save_state(slug, state)
                st.success("Tournament finalized! Review final standings below.")
                st.rerun()
        
        if finalized and not hard_locked:
            st.markdown("---")
            st.success("✅ Tournament Soft Finalized")
            
            st.subheader("Final Standings")
            final_standings = compute_swiss_standings(swiss_teams, swiss_rounds, "end_of_round")
            
            for rank, (mp, bp, buchholz, tid) in enumerate(final_standings, start=1):
                if rank == 1:
                    st.write(f"🥇 {rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")
                elif rank == 2:
                    st.write(f"🥈 {rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")
                elif rank == 3:
                    st.write(f"🥉 {rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")
                else:
                    st.write(f"{rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")
            
            st.markdown("---")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("↩️ Undo Finalization"):
                    swiss["finalized"] = False
                    save_state(slug, state)
                    st.rerun()
            with col2:
                if st.button("🔒 Confirm Finalization (LOCK)", type="primary"):
                    swiss["hard_locked"] = True
                    state["stage"] = "swiss_finalized"
                    save_state(slug, state)
                    st.success("Tournament HARD LOCKED. No further edits allowed.")
                    st.rerun()
        
        if hard_locked:
            st.markdown("---")
            st.error("🔒 Tournament is HARD LOCKED. No edits allowed.")
            
            st.subheader("Final Standings")
            final_standings = compute_swiss_standings(swiss_teams, swiss_rounds, "end_of_round")
            
            for rank, (mp, bp, buchholz, tid) in enumerate(final_standings, start=1):
                if rank == 1:
                    st.write(f"🥇 {rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")
                elif rank == 2:
                    st.write(f"🥈 {rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")
                elif rank == 3:
                    st.write(f"🥉 {rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")
                else:
                    st.write(f"{rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}, TB1={buchholz}")