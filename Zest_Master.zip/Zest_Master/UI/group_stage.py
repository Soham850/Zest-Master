import streamlit as st
import json
import random
from pathlib import Path
from datetime import datetime

DATA_DIR = Path("data/tournaments/active")

def load_state(slug):
    path = DATA_DIR / slug / "state.json"
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_state(slug, state):
    path = DATA_DIR / slug / "state.json"
    state["updated"] = datetime.now().isoformat(timespec="seconds")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)

def next_pool_name(existing_names):
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for letter in letters:
        candidate = f"Pool {letter}"
        if candidate not in existing_names:
            return candidate
    return f"Pool {len(existing_names)+1}"

def generate_round_robin(team_ids):
    """Generate round-robin pairings for a pool using circle method."""
    n = len(team_ids)
    if n == 0:
        return []
    
    # Add bye if odd number of teams
    teams = team_ids.copy()
    if n % 2 == 1:
        teams.append("BYE")
        n += 1
    
    rounds = []
    num_rounds = n - 1
    
    for round_num in range(num_rounds):
        matches = []
        for i in range(n // 2):
            idx1 = i
            idx2 = n - 1 - i
            
            team1 = teams[idx1]
            team2 = teams[idx2]
            
            # Handle bye
            if team1 == "BYE":
                matches.append({"bye": team2})
            elif team2 == "BYE":
                matches.append({"bye": team1})
            else:
                # Alternate colors: even rounds first team is white
                if round_num % 2 == 0:
                    matches.append({"white": team1, "black": team2})
                else:
                    matches.append({"white": team2, "black": team1})
        
        rounds.append({"round": round_num + 1, "matches": matches})
        
        # Rotate for next round (keep first team fixed)
        teams = [teams[0]] + [teams[-1]] + teams[1:-1]
    
    return rounds

def render(slug):
    if slug is None:
        st.info("No active tournament selected.")
        return
    
    state = load_state(slug)
    if state is None:
        st.error("Cannot load tournament.")
        return
    
    st.title("Group Stage — Pools")
    
    teams = state["teams"]
    pools = state.get("pools", [])
    rr_generated = state.get("group_rr_generated", False)
    
    # Alphabetical order
    pools.sort(key=lambda p: p["name"])
    
    st.subheader("Pools")
    
    # Add Pool
    if not rr_generated:
        if st.button("Add Pool"):
            existing = [p["name"] for p in pools]
            pools.append({
                "name": next_pool_name(existing),
                "team_ids": [],
                "rounds": []
            })
            state["pools"] = pools
            save_state(slug, state)
            st.rerun()
    
    # Display Pools + Assign Teams
    team_names = {tid: teams[tid]["name"] for tid in teams}
    
    for i, pool in enumerate(pools):
        with st.expander(pool["name"], expanded=True):
            if not rr_generated:
                # Rename pool
                new_name = st.text_input("Rename Pool", value=pool["name"], key=f"pn_{i}")
                if new_name != pool["name"]:
                    if any(p["name"] == new_name for p in pools if p is not pool):
                        st.warning("Pool name must be unique.")
                    elif new_name.strip():
                        pool["name"] = new_name.strip()
                        state["pools"] = pools
                        save_state(slug, state)
                        st.rerun()
                
                # Delete pool
                if st.button("Delete Pool", key=f"del_pool_{i}"):
                    pools.pop(i)
                    state["pools"] = pools
                    save_state(slug, state)
                    st.rerun()
                
                # Team assignment
                options = list(team_names.values())
                rev_lookup = {v: k for k, v in team_names.items()}
                current = [team_names[tid] for tid in pool["team_ids"]]
                sel = st.multiselect("Teams", options, default=current, key=f"ms_{i}")
                
                new_ids = [rev_lookup[name] for name in sel]
                pool["team_ids"] = new_ids
                
                # Save immediately after selection change
                state["pools"] = pools
                save_state(slug, state)
            else:
                # Locked display
                st.write(", ".join(team_names[tid] for tid in pool["team_ids"]))
    
    # Pool Tools
    if not rr_generated and pools:
        st.subheader("Pool Tools")
        
        # Auto distribute
        if st.button("Auto-Distribute Evenly"):
            team_ids = list(teams.keys())
            random.shuffle(team_ids)
            k = len(pools)
            for p in pools:
                p["team_ids"] = []
            for pi, tid in enumerate(team_ids):
                pools[pi % k]["team_ids"].append(tid)
            state["pools"] = pools
            save_state(slug, state)
            st.rerun()
        
        # Shuffle
        if st.button("Shuffle Assignments"):
            all_ids = [tid for p in pools for tid in p["team_ids"]]
            random.shuffle(all_ids)
            for p in pools:
                p["team_ids"] = []
            k = len(pools)
            for i, tid in enumerate(all_ids):
                pools[i % k]["team_ids"].append(tid)
            state["pools"] = pools
            save_state(slug, state)
            st.rerun()
        
        # Clear
        if st.button("Clear Assignments"):
            for p in pools:
                p["team_ids"] = []
            state["pools"] = pools
            save_state(slug, state)
            st.rerun()
    
    # Validation before RR
    if pools and not rr_generated:
        st.subheader("Validation")
        
        assigned = {tid for p in pools for tid in p["team_ids"]}
        msg_ok = True
        
        if len(assigned) != len(teams):
            st.warning("All teams must be assigned to exactly one pool.")
            msg_ok = False
        
        empty = [p["name"] for p in pools if len(p["team_ids"]) == 0]
        if empty:
            st.warning(f"Empty Pools: {', '.join(empty)}")
            msg_ok = False
        
        sizes = [len(p["team_ids"]) for p in pools]
        if sizes and len(set(sizes)) > 1:
            st.info(f"Pools are uneven: sizes={sizes}. This is allowed but unusual.")
        
        if msg_ok:
            if st.button("Generate Round Robin Pairings"):
                # Generate RR for each pool
                for pool in pools:
                    pool["rounds"] = generate_round_robin(pool["team_ids"])
                
                state["pools"] = pools
                state["group_rr_generated"] = True
                save_state(slug, state)
                st.success("Round Robin pairings generated!")
                st.rerun()
    
    # Display RR Pairings + Override
    if rr_generated:
        st.subheader("Round Robin Pairings")
        
        modified = False
        for pi, pool in enumerate(pools):
            st.markdown(f"### {pool['name']}")
            
            for rnd in pool["rounds"]:
                st.write(f"**Round {rnd['round']}**")
                
                for mi, match in enumerate(rnd["matches"]):
                    if "bye" in match:
                        tid = match["bye"]
                        if tid != "BYE":
                            st.write(f"{teams[tid]['name']} has a bye")
                        else:
                            st.write("BYE")
                    else:
                        white = teams[match["white"]]["name"]
                        black = teams[match["black"]]["name"]
                        col = st.columns([6, 1])
                        with col[0]:
                            st.write(f"{white} (White) vs {black} (Black)")
                        with col[1]:
                            if st.button("     ", key=f"swap_{pi}_{rnd['round']}_{mi}"):
                                match["white"], match["black"] = match["black"], match["white"]
                                modified = True
                
                st.markdown("---")
        
        if modified:
            state["pools"] = pools
            save_state(slug, state)
            st.rerun()
        
        # Lock RR & Start Group Stage
        if st.button("Lock RR & Start Group Stage"):
            # Ensure each team has a base board order
            for tid, t in state["teams"].items():
                if "base_board_order" not in t:
                    # Default = players listed in order (take first 4 players)
                    t["base_board_order"] = t["players"][:4]
            
            # Save the base board orders
            save_state(slug, state)

            state["stage"] = "group_running"
            
            # Initialize player_stats structure
            state["player_stats"] = {}
            for tid in state["teams"]:
                for pid in state["teams"][tid]["players"]:
                    state["player_stats"][pid] = {
                        "group": {
                            "played": 0,
                            "w": 0,
                            "d": 0,
                            "l": 0,
                            "score": 0,
                            "boards": [],
                            "teams": state["teams"][tid]["name"]
                        },
                        "swiss": {
                            "played": 0,
                            "w": 0,
                            "d": 0,
                            "l": 0,
                            "score": 0,
                            "boards": [],
                            "teams": state["teams"][tid]["name"]
                        },
                        "total": {
                            "played": 0,
                            "w": 0,
                            "d": 0,
                            "l": 0,
                            "score": 0,
                            "boards": []
                        }
                    }
            
            # Initialize group structure
            group = {"pools": []}
            
            for pool in pools:
                pool_copy = pool.copy()
                pool_copy["current_round"] = 1
                pool_copy["locked_rounds"] = {}
                pool_copy["standings"] = {}
                pool_copy["qualifiers"] = 1  # Default qualifiers
                
                # Initialize match structures
                for rnd in pool_copy["rounds"]:
                    for match in rnd["matches"]:
                        if "bye" not in match:
                            match["lineup1"] = None
                            match["lineup2"] = None
                            match["board_results"] = [None, None, None, None]
                            match["bp1"] = 0
                            match["bp2"] = 0
                            match["mp1"] = 0
                            match["mp2"] = 0
                            match["status"] = "pending"
                
                group["pools"].append(pool_copy)
            
            state["group"] = group
            save_state(slug, state)
            st.success("Group Stage Started!")
            st.rerun()
    
    # Group Stage Execution
    if state.get("stage") == "group_running":
        st.title("Group Stage — Execution")
        
        group = state["group"]
        pools = group["pools"]
        
        tab_labels = [p["name"] for p in pools]
        tabs = st.tabs(tab_labels)
        
        for idx, pool in enumerate(pools):
            with tabs[idx]:
                rounds = pool["rounds"]
                total_rounds = len(rounds)
                cr = pool.get("current_round", 1)
                
                st.subheader(f"{pool['name']} — Round {cr}/{total_rounds}")
                
                # Navigation
                c1, c2 = st.columns([1, 1])
                if c1.button("Prev", disabled=(cr == 1), key=f"prv_{idx}"):
                    pool["current_round"] = cr - 1
                    save_state(slug, state)
                    st.rerun()
                if c2.button("Next", disabled=(cr == total_rounds), key=f"nxt_{idx}"):
                    pool["current_round"] = cr + 1
                    save_state(slug, state)
                    st.rerun()
                
                # Current round matches
                rnd = rounds[cr - 1]
                st.write("### Matches")
                
                for mi, match in enumerate(rnd["matches"]):
                    if "bye" in match:
                        tid = match["bye"]
                        st.info(f"{state['teams'][tid]['name']} has a bye")
                        continue
                    
                    t1_id = match['white']
                    t2_id = match['black']
                    t1 = state['teams'][t1_id]['name']
                    t2 = state['teams'][t2_id]['name']
                    
                    st.write(f"**{t1} (White) — {t2} (Black)**")
                    
                    # Lineup confirmation and editing
                    if match.get("lineup1") is None or match.get("lineup2") is None:
                        with st.expander("Set Lineups", expanded=True):
                            # Initialize session state lineups if not present
                            session_key_t1 = f"lineup1_{idx}_{cr}_{mi}"
                            session_key_t2 = f"lineup2_{idx}_{cr}_{mi}"
                            
                            # Team 1 (White) Lineup
                            st.write(f"**{t1} (White) Lineup:**")
                            
                            t1_players = state['teams'][t1_id]['players']
                            t1_player_names = {pid: state['players'][pid]['name'] for pid in t1_players}
                            
                            # Get base order, ensure it has 4 players
                            base_order_t1 = state['teams'][t1_id].get('base_board_order', [])
                            if not base_order_t1 or len(base_order_t1) < 4:
                                base_order_t1 = t1_players[:4]
                            else:
                                base_order_t1 = base_order_t1[:4]
                            
                            # Initialize if not in session state
                            if session_key_t1 not in st.session_state:
                                st.session_state[session_key_t1] = base_order_t1.copy()
                            
                            # Display base order
                            st.caption("Base Board Order:")
                            for i, pid in enumerate(base_order_t1):
                                st.caption(f"  Board {i+1}: {t1_player_names[pid]}")
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                if st.button("Reset to Base Order", key=f"base1_{idx}_{mi}"):
                                    st.session_state[session_key_t1] = base_order_t1.copy()
                                    st.rerun()
                            with col2:
                                if st.button("Make Substitution", key=f"sub1_{idx}_{mi}"):
                                    st.session_state[f"show_sub1_{idx}_{mi}"] = True
                                    st.rerun()
                            
                            # Show substitution interface
                            if st.session_state.get(f"show_sub1_{idx}_{mi}", False):
                                current_lineup_t1 = st.session_state[session_key_t1]
                                
                                st.write("**Select player to bench:**")
                                benched_t1 = st.selectbox(
                                    "Bench",
                                    options=current_lineup_t1,
                                    format_func=lambda x: t1_player_names[x],
                                    key=f"bench1_{idx}_{mi}"
                                )
                                
                                # Get available substitutes (not in current lineup)
                                available_subs_t1 = [p for p in t1_players if p not in current_lineup_t1]
                                
                                if available_subs_t1:
                                    st.write("**Select substitute:**")
                                    sub_t1 = st.selectbox(
                                        "Substitute",
                                        options=available_subs_t1,
                                        format_func=lambda x: t1_player_names[x],
                                        key=f"subplayer1_{idx}_{mi}"
                                    )
                                    
                                    col_apply, col_cancel = st.columns(2)
                                    with col_apply:
                                        if st.button("Apply FIDE Ladder", key=f"apply1_{idx}_{mi}"):
                                            # FIDE Ladder: substitute plays on last board
                                            # Players below benched player move up
                                            new_lineup = current_lineup_t1.copy()
                                            benched_idx = new_lineup.index(benched_t1)
                                            
                                            # Remove benched player
                                            new_lineup.pop(benched_idx)
                                            # Add substitute at the end
                                            new_lineup.append(sub_t1)
                                            
                                            st.session_state[session_key_t1] = new_lineup
                                            st.session_state[f"show_sub1_{idx}_{mi}"] = False
                                            st.success(f"✓ {t1_player_names[sub_t1]} substitutes for {t1_player_names[benched_t1]}")
                                            st.rerun()
                                    with col_cancel:
                                        if st.button("Cancel", key=f"cancel1_{idx}_{mi}"):
                                            st.session_state[f"show_sub1_{idx}_{mi}"] = False
                                            st.rerun()
                                else:
                                    st.warning("No available substitutes")
                                    if st.button("Cancel", key=f"cancel1_nosub_{idx}_{mi}"):
                                        st.session_state[f"show_sub1_{idx}_{mi}"] = False
                                        st.rerun()
                            
                            # Display current lineup
                            current_lineup_t1 = st.session_state[session_key_t1]
                            st.write("**Current Lineup:**")
                            for i, pid in enumerate(current_lineup_t1):
                                st.write(f"Board {i+1}: {t1_player_names[pid]}")
                            
                            st.markdown("---")
                            
                            # Team 2 (Black) Lineup
                            st.write(f"**{t2} (Black) Lineup:**")
                            
                            t2_players = state['teams'][t2_id]['players']
                            t2_player_names = {pid: state['players'][pid]['name'] for pid in t2_players}
                            
                            # Get base order, ensure it has 4 players
                            base_order_t2 = state['teams'][t2_id].get('base_board_order', [])
                            if not base_order_t2 or len(base_order_t2) < 4:
                                base_order_t2 = t2_players[:4]
                            else:
                                base_order_t2 = base_order_t2[:4]
                            
                            # Initialize if not in session state
                            if session_key_t2 not in st.session_state:
                                st.session_state[session_key_t2] = base_order_t2.copy()
                            
                            # Display base order
                            st.caption("Base Board Order:")
                            for i, pid in enumerate(base_order_t2):
                                st.caption(f"  Board {i+1}: {t2_player_names[pid]}")
                            
                            col1, col2 = st.columns(2)
                            with col1:
                                if st.button("Reset to Base Order", key=f"base2_{idx}_{mi}"):
                                    st.session_state[session_key_t2] = base_order_t2.copy()
                                    st.rerun()
                            with col2:
                                if st.button("Make Substitution", key=f"sub2_{idx}_{mi}"):
                                    st.session_state[f"show_sub2_{idx}_{mi}"] = True
                                    st.rerun()
                            
                            # Show substitution interface
                            if st.session_state.get(f"show_sub2_{idx}_{mi}", False):
                                current_lineup_t2 = st.session_state[session_key_t2]
                                
                                st.write("**Select player to bench:**")
                                benched_t2 = st.selectbox(
                                    "Bench",
                                    options=current_lineup_t2,
                                    format_func=lambda x: t2_player_names[x],
                                    key=f"bench2_{idx}_{mi}"
                                )
                                
                                # Get available substitutes (not in current lineup)
                                available_subs_t2 = [p for p in t2_players if p not in current_lineup_t2]
                                
                                if available_subs_t2:
                                    st.write("**Select substitute:**")
                                    sub_t2 = st.selectbox(
                                        "Substitute",
                                        options=available_subs_t2,
                                        format_func=lambda x: t2_player_names[x],
                                        key=f"subplayer2_{idx}_{mi}"
                                    )
                                    
                                    col_apply, col_cancel = st.columns(2)
                                    with col_apply:
                                        if st.button("Apply FIDE Ladder", key=f"apply2_{idx}_{mi}"):
                                            # FIDE Ladder: substitute plays on last board
                                            # Players below benched player move up
                                            new_lineup = current_lineup_t2.copy()
                                            benched_idx = new_lineup.index(benched_t2)
                                            
                                            # Remove benched player
                                            new_lineup.pop(benched_idx)
                                            # Add substitute at the end
                                            new_lineup.append(sub_t2)
                                            
                                            st.session_state[session_key_t2] = new_lineup
                                            st.session_state[f"show_sub2_{idx}_{mi}"] = False
                                            st.success(f"✓ {t2_player_names[sub_t2]} substitutes for {t2_player_names[benched_t2]}")
                                            st.rerun()
                                    with col_cancel:
                                        if st.button("Cancel", key=f"cancel2_{idx}_{mi}"):
                                            st.session_state[f"show_sub2_{idx}_{mi}"] = False
                                            st.rerun()
                                else:
                                    st.warning("No available substitutes")
                                    if st.button("Cancel", key=f"cancel2_nosub_{idx}_{mi}"):
                                        st.session_state[f"show_sub2_{idx}_{mi}"] = False
                                        st.rerun()
                            
                            # Display current lineup
                            current_lineup_t2 = st.session_state[session_key_t2]
                            st.write("**Current Lineup:**")
                            for i, pid in enumerate(current_lineup_t2):
                                st.write(f"Board {i+1}: {t2_player_names[pid]}")
                            
                            st.markdown("---")
                            
                            # Confirm both lineups
                            if st.button(f"Confirm Lineups", key=f"lu_confirm_{idx}_{mi}"):
                                # Save lineups to match state (persisted to JSON)
                                match["lineup1"] = st.session_state[session_key_t1]
                                match["lineup2"] = st.session_state[session_key_t2]
                                
                                # Save to file
                                save_state(slug, state)
                                
                                # Clear temporary session state for this match
                                st.session_state.pop(session_key_t1, None)
                                st.session_state.pop(session_key_t2, None)
                                st.session_state.pop(f"show_sub1_{idx}_{mi}", None)
                                st.session_state.pop(f"show_sub2_{idx}_{mi}", None)
                                
                                st.success("✅ Lineups confirmed and saved!")
                                st.rerun()
                    else:
                        # Display confirmed lineups with edit option
                        with st.expander("View/Edit Lineups"):
                            c1, c2 = st.columns(2)

                            with c1:
                                st.markdown(f"**{t1} (White)**")
                                for board, pid in enumerate(match["lineup1"], start=1):
                                    st.write(f"Board {board}: {state['players'][pid]['name']}")

                            with c2:
                                st.markdown(f"**{t2} (Black)**")
                                for board, pid in enumerate(match["lineup2"], start=1):
                                    st.write(f"Board {board}: {state['players'][pid]['name']}")

                            st.markdown("---")

                            if st.button("Edit Lineups", key=f"edit_lu_{idx}_{mi}"):
                                match["lineup1"] = None
                                match["lineup2"] = None
                                save_state(slug, state)
                                st.rerun()

                        
                        # Hotkey input
                        hk = st.text_input("Hotkey (z=1-0, x=½-½, c=0-1)", value="", 
                                          key=f"hk_{idx}_{mi}", max_chars=1)
                        if hk:
                            for b in range(4):
                                if match["board_results"][b] is None:
                                    if hk.lower() == "z":
                                        match["board_results"][b] = 1
                                    elif hk.lower() == "x":
                                        match["board_results"][b] = 0.5
                                    elif hk.lower() == "c":
                                        match["board_results"][b] = 0
                            save_state(slug, state)
                            st.rerun()
                        
                        # Board result buttons
                        cols = st.columns(4)
                        for b in range(4):
                            r = match["board_results"][b]
                            with cols[b]:
                                # Show player names
                                wp_name = state['players'][match["lineup1"][b]]['name']
                                bp_name = state['players'][match["lineup2"][b]]['name']
                                st.caption(f"{wp_name} vs {bp_name}")
                                
                                if r is None:
                                    if st.button("1-0", key=f"w_{idx}_{mi}_{b}"):
                                        match["board_results"][b] = 1
                                        save_state(slug, state)
                                        st.rerun()
                                    if st.button("½-½", key=f"d_{idx}_{mi}_{b}"):
                                        match["board_results"][b] = 0.5
                                        save_state(slug, state)
                                        st.rerun()
                                    if st.button("0-1", key=f"l_{idx}_{mi}_{b}"):
                                        match["board_results"][b] = 0
                                        save_state(slug, state)
                                        st.rerun()
                                else:
                                    st.success(f"Board {b+1}: {r}")
                                    if st.button("Reset", key=f"reset_{idx}_{mi}_{b}"):
                                        match["board_results"][b] = None
                                        save_state(slug, state)
                                        st.rerun()
                        
                        # Scoring and stats update
                        if all(r is not None for r in match["board_results"]):
                            bp1 = sum(1 if r == 1 else 0.5 if r == 0.5 else 0 
                                     for r in match["board_results"])
                            bp2 = 4 - bp1
                            match["bp1"] = bp1
                            match["bp2"] = bp2
                            match["mp1"] = 1 if bp1 >= 2.5 else 0.5 if bp1 == 2 else 0
                            match["mp2"] = 1 if bp2 >= 2.5 else 0.5 if bp2 == 2 else 0
                            match["status"] = "done"
                            
                            # Update individual player stats
                            white_pids = match["lineup1"]
                            black_pids = match["lineup2"]
                            
                            # Ensure player_stats exists and is initialized
                            if "player_stats" not in state:
                                state["player_stats"] = {}

                            for b in range(4):
                                r = match["board_results"][b]
                                wp = white_pids[b]
                                bp = black_pids[b]

                                pst = state["player_stats"]
                                
                                # Initialize player stats if missing
                                for pid in [wp, bp]:
                                    if pid not in pst:
                                        # Find team for this player
                                        team_name = "Unknown"
                                        for tid in state["teams"]:
                                            if pid in state["teams"][tid]["players"]:
                                                team_name = state["teams"][tid]["name"]
                                                break
                                        
                                        pst[pid] = {
                                            "group": {
                                                "played": 0,
                                                "w": 0,
                                                "d": 0,
                                                "l": 0,
                                                "score": 0,
                                                "boards": [],
                                                "teams": team_name
                                            },
                                            "swiss": {
                                                "played": 0,
                                                "w": 0,
                                                "d": 0,
                                                "l": 0,
                                                "score": 0,
                                                "boards": [],
                                                "teams": team_name
                                            },
                                            "total": {
                                                "played": 0,
                                                "w": 0,
                                                "d": 0,
                                                "l": 0,
                                                "score": 0,
                                                "boards": []
                                            }
                                        }

                                # Record board played
                                if (b + 1) not in pst[wp]["group"]["boards"]:
                                    pst[wp]["group"]["boards"].append(b + 1)
                                if (b + 1) not in pst[bp]["group"]["boards"]:
                                    pst[bp]["group"]["boards"].append(b + 1)

                                # Assign score
                                if r == 1:
                                    pst[wp]["group"]["w"] += 1
                                    pst[bp]["group"]["l"] += 1
                                    pst[wp]["group"]["score"] += 1
                                elif r == 0.5:
                                    pst[wp]["group"]["d"] += 1
                                    pst[bp]["group"]["d"] += 1
                                    pst[wp]["group"]["score"] += 0.5
                                    pst[bp]["group"]["score"] += 0.5
                                else:
                                    pst[wp]["group"]["l"] += 1
                                    pst[bp]["group"]["w"] += 1
                                    pst[bp]["group"]["score"] += 1

                                pst[wp]["group"]["played"] += 1
                                pst[bp]["group"]["played"] += 1

                            # Update total stats
                            for pid in state["player_stats"]:
                                stt = state["player_stats"][pid]
                                stt["total"]["played"] = stt["group"]["played"] + stt["swiss"]["played"]
                                stt["total"]["w"] = stt["group"]["w"] + stt["swiss"]["w"]
                                stt["total"]["d"] = stt["group"]["d"] + stt["swiss"]["d"]
                                stt["total"]["l"] = stt["group"]["l"] + stt["swiss"]["l"]
                                stt["total"]["score"] = stt["group"]["score"] + stt["swiss"]["score"]
                                stt["total"]["boards"] = stt["group"]["boards"] + stt["swiss"]["boards"]

                            save_state(slug, state)
                
                # Standings
                st.write("### Standings")
                tbl = []
                for tid in pool["team_ids"]:
                    mp = bp = 0
                    for rnd_obj in pool["rounds"]:
                        for match in rnd_obj["matches"]:
                            if "bye" in match:
                                continue
                            if match.get("status") != "done":
                                continue
                            if match["white"] == tid:
                                mp += match["mp1"]
                                bp += match["bp1"]
                            elif match["black"] == tid:
                                mp += match["mp2"]
                                bp += match["bp2"]
                    tbl.append((mp, bp, tid))
                
                tbl.sort(reverse=True)
                
                # Qualifiers setting
                if "qualifiers" not in pool:
                    pool["qualifiers"] = 1
                
                q_val = st.number_input(
                    "Qualifiers from this pool",
                    min_value=1,
                    max_value=len(pool["team_ids"]),
                    value=pool["qualifiers"],
                    key=f"qual_{idx}"
                )
                pool["qualifiers"] = q_val
                save_state(slug, state)
                
                # Show qualification line
                show_q = st.checkbox("Show Qualification Line", key=f"showq_{idx}")
                
                if show_q:
                    st.write("---")
                    st.write(f"Top {q_val} qualify")
                
                for rank, (mp, bp, tid) in enumerate(tbl, start=1):
                    line = f"{rank}. {state['teams'][tid]['name']} — MP={mp}, BP={bp}"
                    if show_q and rank == q_val:
                        st.write(line)
                        st.markdown("---")
                    else:
                        st.write(line)
                
                # Round confirmation
                round_done = all(
                    match.get("status") == "done" or "bye" in match
                    for match in rnd["matches"]
                )
                
                locked_rounds = pool.get("locked_rounds", {})
                
                if str(cr) not in locked_rounds:
                    if round_done:
                        if st.button("Confirm Round", key=f"lock_{idx}_{cr}"):
                            locked_rounds[str(cr)] = True
                            pool["locked_rounds"] = locked_rounds
                            save_state(slug, state)
                            
                            # Auto-advance
                            if cr < total_rounds:
                                pool["current_round"] = cr + 1
                                save_state(slug, state)
                            st.rerun()
                    else:
                        st.info("Round cannot be confirmed until all matches are completed.")
                else:
                    st.success("Round Confirmed & Locked")
                    
                    # TD Override
                    if st.button("Override Round (TD Only)", key=f"ovr_{idx}_{cr}"):
                        locked_rounds.pop(str(cr))
                        pool["locked_rounds"] = locked_rounds
                        
                        # Reset match data
                        for match in rnd["matches"]:
                            if "bye" not in match:
                                # Revert player stats before resetting match
                                if match.get("lineup1") and match.get("lineup2"):
                                    white_pids = match["lineup1"]
                                    black_pids = match["lineup2"]
                                    
                                    for b in range(4):
                                        if match["board_results"][b] is not None:
                                            r = match["board_results"][b]
                                            wp = white_pids[b]
                                            bp = black_pids[b]
                                            pst = state["player_stats"]
                                            
                                            # Revert stats
                                            if r == 1:
                                                pst[wp]["group"]["w"] -= 1
                                                pst[bp]["group"]["l"] -= 1
                                                pst[wp]["group"]["score"] -= 1
                                            elif r == 0.5:
                                                pst[wp]["group"]["d"] -= 1
                                                pst[bp]["group"]["d"] -= 1
                                                pst[wp]["group"]["score"] -= 0.5
                                                pst[bp]["group"]["score"] -= 0.5
                                            else:
                                                pst[wp]["group"]["l"] -= 1
                                                pst[bp]["group"]["w"] -= 1
                                                pst[bp]["group"]["score"] -= 1
                                            
                                            pst[wp]["group"]["played"] -= 1
                                            pst[bp]["group"]["played"] -= 1
                                
                                match["status"] = "pending"
                                match["board_results"] = [None, None, None, None]
                                match["bp1"] = 0
                                match["bp2"] = 0
                                match["mp1"] = 0
                                match["mp2"] = 0
                        
                        # Update total stats after revert
                        for pid in state["player_stats"]:
                            stt = state["player_stats"][pid]
                            stt["total"]["played"] = stt["group"]["played"] + stt["swiss"]["played"]
                            stt["total"]["w"] = stt["group"]["w"] + stt["swiss"]["w"]
                            stt["total"]["d"] = stt["group"]["d"] + stt["swiss"]["d"]
                            stt["total"]["l"] = stt["group"]["l"] + stt["swiss"]["l"]
                            stt["total"]["score"] = stt["group"]["score"] + stt["swiss"]["score"]
                            stt["total"]["boards"] = stt["group"]["boards"] + stt["swiss"]["boards"]
                        
                        save_state(slug, state)
                        st.warning("Round unlocked for editing by TD override.")
                        st.rerun()