import streamlit as st
from pathlib import Path
import json
import shutil
import re
from datetime import date


DATA_DIR = Path("data/tournaments")
ACTIVE_DIR = DATA_DIR / "active"
ARCHIVE_DIR = DATA_DIR / "archive"


def ensure_dirs():
    ACTIVE_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)


def slugify(name: str) -> str:
    # lowercase, replace non-alnum with underscore, collapse underscores
    slug = re.sub(r'[^a-zA-Z0-9]+', '_', name.lower())
    slug = re.sub(r'_+', '_', slug).strip('_')
    return slug


def render():
    st.title("Tournaments")

    ensure_dirs()

    st.subheader("Create New Tournament")

    # --- Tournament Creation Form ---
    with st.form("create_tournament"):
        name = st.text_input("Tournament Name")
        venue = st.text_input("Venue / Location")
        organizer = st.text_input("Organizer", value="")
        arbiter = st.text_input("Chief Arbiter", value="")
        deputy = st.text_input("Deputy Arbiter", value="")
        time_control = st.text_input("Time Control", value="90+30")
        start_date = st.date_input("Start Date", value=date.today())
        end_date = st.date_input("End Date", value=date.today())
        notes = st.text_area("Notes (optional)", value="")

        submitted = st.form_submit_button("Create Tournament")

        if submitted:
            if not name:
                st.error("Tournament name cannot be empty.")
            else:
                slug = slugify(name)
                tournament_path = ACTIVE_DIR / slug

                if tournament_path.exists():
                    st.error(f"Tournament '{name}' already exists.")
                else:
                    tournament_path.mkdir(parents=True)
                    (tournament_path / "snapshots").mkdir()
                    (tournament_path / "exports").mkdir()

                    # Initial state.json
                    initial_state = {
                        "metadata": {
                            "name": name,
                            "venue": venue,
                            "organizer": organizer,
                            "arbiter": arbiter,
                            "deputy_arbiter": deputy,
                            "time_control": time_control,
                            "start_date": str(start_date),
                            "end_date": str(end_date),
                            "notes": notes,
                            "format": "group+swiss",
                        },
                        "stage": "group",
                        "teams": {},
                        "players": {},
                        "pools": [],
                        "swiss": None,
                        "created": str(date.today()),
                        "updated": str(date.today())
                    }

                    with open(tournament_path / "state.json", "w", encoding="utf-8") as f:
                        json.dump(initial_state, f, indent=2)

                    st.success(f"Tournament '{name}' created successfully!")


    st.markdown("---")
    st.subheader("Active Tournaments")

    # --- List Active Events ---
    for folder in ACTIVE_DIR.iterdir():
        if not folder.is_dir():
            continue
        state_file = folder / "state.json"
        if not state_file.exists():
            continue

        with open(state_file, "r", encoding="utf-8") as f:
            state = json.load(f)

        with st.container():
            st.write(f"**{state['metadata']['name']}**")
            st.write(f"Stage: {state['stage']}")
            st.write(f"Updated: {state.get('updated', 'N/A')}")

            col1, col2, col3, col4 = st.columns(4)

            if col1.button("Open", key=f"open_{folder.name}"):
                st.session_state["active_tournament"] = folder.name

            if col2.button("Clone", key=f"clone_{folder.name}"):
                st.session_state["clone_tournament"] = folder.name

            if col3.button("View", key=f"view_{folder.name}"):
                st.session_state["view_tournament"] = folder.name

            if col4.button("Archive", key=f"archive_{folder.name}"):
                shutil.move(str(folder), ARCHIVE_DIR / folder.name)
                st.experimental_rerun()


    st.markdown("---")
    st.subheader("Archived Tournaments")

    # --- List Archived Events ---
    for folder in ARCHIVE_DIR.iterdir():
        if not folder.is_dir():
            continue

        state_file = folder / "state.json"
        if not state_file.exists():
            continue

        with open(state_file, "r", encoding="utf-8") as f:
            state = json.load(f)

        with st.container():
            st.write(f"**{state['metadata']['name']}** (Archived)")
            col1, col2 = st.columns(2)

            if col1.button("Restore", key=f"restore_{folder.name}"):
                shutil.move(str(folder), ACTIVE_DIR / folder.name)
                st.experimental_rerun()

            if col2.button("Delete", key=f"delete_{folder.name}"):
                shutil.rmtree(folder)
                st.experimental_rerun()
