from core.models import TournamentState, SwissTournament, Round, TeamMatch
from core.results import compute_board_points, compute_match_points, apply_individual_results


def start_swiss(state: TournamentState, qualified_team_ids: list[str]):
    """
    Initialize swiss stage and reset relevant stats
    """
    state.stage = "swiss"
    state.swiss = SwissTournament(
        qualified_team_ids=qualified_team_ids,
        rounds=[]
    )

    # Reset team swiss stats
    for tid in qualified_team_ids:
        t = state.teams[tid]
        t.swiss_match_points = 0.0
        t.swiss_board_points = 0.0

    # Reset individuals for swiss
    for p in state.players.values():
        if p.team_id in qualified_team_ids:
            p.individual_points = 0.0
            p.games_played = 0


def add_swiss_round(state: TournamentState) -> Round:
    rnd_number = len(state.swiss.rounds) + 1
    new_rnd = Round(round_number=rnd_number, matches=[], is_completed=False)
    state.swiss.rounds.append(new_rnd)
    return new_rnd


def add_swiss_match(state: TournamentState, rnd: Round, white_team_id: str, black_team_id: str):
    """
    Admin adds a match manually based on SwissPerfect pairings.
    """
    match = TeamMatch(
        white_team_id=white_team_id,
        black_team_id=black_team_id,
        board_results=[]  # will fill later
    )
    rnd.matches.append(match)


def complete_swiss_round(state: TournamentState, rnd: Round):
    """
    Compute points and update standings for the round.
    """
    for match in rnd.matches:
        compute_board_points(match)
        compute_match_points(match)

        # Update swiss team stats
        wt = state.teams[match.white_team_id]
        bt = state.teams[match.black_team_id]

        wt.swiss_board_points += match.white_board_points
        bt.swiss_board_points += match.black_board_points

        wt.swiss_match_points += match.white_match_points
        bt.swiss_match_points += match.black_match_points

        # Update individual stats (shared logic)
        apply_individual_results(state, match)

    rnd.is_completed = True
