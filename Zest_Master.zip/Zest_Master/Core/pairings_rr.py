from typing import List
from core.models import Round, TeamMatch


def round_robin_pairings(team_ids: List[str], double_round: bool = False) -> List[Round]:
    teams = team_ids.copy()
    n = len(teams)

    bye_team = None
    if n % 2 == 1:
        bye_team = "_BYE_"
        teams.append(bye_team)
        n += 1

    rounds = []
    half = n // 2

    # Generate first cycle
    for rnd in range(1, n):
        matches = []
        for i in range(half):
            t1 = teams[i]
            t2 = teams[n - 1 - i]

            if t1 != "_BYE_" and t2 != "_BYE_":
                # color alternation by round parity
                if rnd % 2 == 1:
                    white, black = t1, t2
                else:
                    white, black = t2, t1

                matches.append(
                    TeamMatch(
                        white_team_id=white,
                        black_team_id=black,
                        board_results=[]
                    )
                )

        rounds.append(
            Round(
                round_number=rnd,
                matches=matches,
                is_completed=False
            )
        )

        # rotate
        teams = [teams[0]] + teams[-1:] + teams[1:-1]

    # second cycle for double RR
    if double_round:
        second_cycle = []
        base_count = len(rounds)
        for i, rnd in enumerate(rounds):
            new_matches = []
            for m in rnd.matches:
                new_matches.append(
                    TeamMatch(
                        white_team_id=m.black_team_id,
                        black_team_id=m.white_team_id,
                        board_results=[]
                    )
                )
            second_cycle.append(
                Round(
                    round_number=base_count + i + 1,
                    matches=new_matches,
                    is_completed=False
                )
            )
        rounds.extend(second_cycle)

    return rounds
