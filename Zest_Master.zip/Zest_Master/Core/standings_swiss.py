from core.models import TournamentState

def get_swiss_standings(state: TournamentState):
    teams = [state.teams[tid] for tid in state.swiss.qualified_team_ids]

    teams_sorted = sorted(
        teams,
        key=lambda t: (t.swiss_match_points, t.swiss_board_points),
        reverse=True
    )

    return teams_sorted
