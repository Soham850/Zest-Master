from core.models import TournamentState, BoardResult


def get_base_lineup(state: TournamentState, team_id: str):
    team = state.teams[team_id]
    players = [state.players[pid] for pid in team.players]
    players_sorted = sorted(players, key=lambda p: p.base_board_order)
    return [p.id for p in players_sorted[:4]]


def apply_substitution(base_lineup: list[str], substitute_id: str | None):
    if substitute_id is None:
        return base_lineup
    return base_lineup[:3] + [substitute_id]


def assign_boards_to_match(match, white_lineup, black_lineup):
    # exactly 4 boards enforced upstream
    match.board_results = [
        BoardResult(white_player_id=w, black_player_id=b)
        for w, b in zip(white_lineup, black_lineup)
    ]
