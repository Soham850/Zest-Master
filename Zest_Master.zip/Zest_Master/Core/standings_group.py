from core.models import TournamentState, Pool


def compute_group_standings(state: TournamentState):
    """
    Recompute all pools standings from scratch.
    This guarantees correctness even after editing matches.
    """

    # reset all stats
    for team in state.teams.values():
        team.group_match_points = 0.0
        team.group_board_points = 0.0

    for player in state.players.values():
        player.individual_points = 0.0
        player.games_played = 0

    # accumulate from rounds
    from core.results import process_group_match_result

    for pool in state.pools:
        for rnd in pool.rounds:
            if rnd.is_completed:
                for match in rnd.matches:
                    process_group_match_result(state, match)


def get_pool_standings(state: TournamentState, pool: Pool):
    """
    Return teams sorted within a pool for UI display.
    """
    teams = [state.teams[tid] for tid in pool.team_ids]

    teams_sorted = sorted(
        teams,
        key=lambda t: (t.group_match_points, t.group_board_points),
        reverse=True
    )

def get_qualified_teams(state: TournamentState, per_pool_k: int) -> List[str]:
    qualified = []

    for pool in state.pools:
        teams_sorted = get_pool_standings(state, pool)

        # take top k
        for t in teams_sorted[:per_pool_k]:
            qualified.append(t.id)

    return qualified

def get_qualified_teams_reseed(state: TournamentState, per_pool_k: int) -> List[str]:
    # extract top-k from each pool
    pool_qualifiers = []

    for pool in state.pools:
        teams_sorted = get_pool_standings(state, pool)
        pool_qualifiers.extend(teams_sorted[:per_pool_k])

    # unified re-seeding
    reseeded = sorted(
        pool_qualifiers,
        key=lambda t: (t.group_match_points, t.group_board_points),
        reverse=True
    )

    return [t.id for t in reseeded]


    return teams_sorted
