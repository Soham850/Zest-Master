from core.models import TeamMatch, TournamentState, BoardResult


def compute_board_points(match: TeamMatch):
    white_bp = 0.0
    black_bp = 0.0

    for br in match.board_results:
        if br.result_white is None or br.result_black is None:
            continue  # incomplete board

        white_bp += float(br.result_white)
        black_bp += float(br.result_black)

    match.white_board_points = white_bp
    match.black_board_points = black_bp


def compute_match_points(match: TeamMatch):
    wb = match.white_board_points
    bb = match.black_board_points

    if wb >= 2.5:
        match.white_match_points = 1.0
        match.black_match_points = 0.0
    elif bb >= 2.5:
        match.white_match_points = 0.0
        match.black_match_points = 1.0
    else:
        match.white_match_points = 0.5
        match.black_match_points = 0.5


def apply_to_group_standings(state: TournamentState, match: TeamMatch):
    wt = state.teams[match.white_team_id]
    bt = state.teams[match.black_team_id]

    wt.group_board_points += match.white_board_points
    bt.group_board_points += match.black_board_points

    wt.group_match_points += match.white_match_points
    bt.group_match_points += match.black_match_points


def apply_individual_results(state: TournamentState, match: TeamMatch):
    for br in match.board_results:
        wp = state.players[br.white_player_id]
        bp = state.players[br.black_player_id]

        if br.result_white is not None:
            wp.individual_points += float(br.result_white)
            wp.games_played += 1

        if br.result_black is not None:
            bp.individual_points += float(br.result_black)
            bp.games_played += 1


def process_group_match_result(state: TournamentState, match: TeamMatch):
    compute_board_points(match)
    compute_match_points(match)
    apply_to_group_standings(state, match)
    apply_individual_results(state, match)
