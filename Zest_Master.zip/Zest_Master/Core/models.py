from dataclasses import dataclass, field
from typing import List, Optional, Dict, Literal
import uuid


def gen_id() -> str:
    return str(uuid.uuid4())


# --------------------------
# Player
# --------------------------

@dataclass
class Player:
    id: str = field(default_factory=gen_id)
    name: str = ""
    team_id: str = ""
    rating: Optional[int] = None 
    base_board_order: int = 0   # 1-4 standard
    individual_points: float = 0.0   # accumulated over full event
    games_played: int = 0


# --------------------------
# Team
# --------------------------

@dataclass
class Team:
    id: str = field(default_factory=gen_id)
    name: str = ""
    players: List[str] = field(default_factory=list)       # player_ids
    substitutes: List[str] = field(default_factory=list)   # player_ids

    # group stage stats
    group_match_points: float = 0.0
    group_board_points: float = 0.0

    # swiss stage stats
    swiss_match_points: float = 0.0
    swiss_board_points: float = 0.0


# --------------------------
# Board Result
# --------------------------

ResultType = Literal[1, 0.5, 0, None]

@dataclass
class BoardResult:
    white_player_id: str
    black_player_id: str
    result_white: Optional[ResultType] = None
    result_black: Optional[ResultType] = None

    # convenience: both must sum to 1 or 1.0 unless none
    # we keep validation later in results.py


# --------------------------
# Team Match (Round element)
# --------------------------

@dataclass
class TeamMatch:
    white_team_id: str
    black_team_id: str
    board_results: List[BoardResult] = field(default_factory=list)

    # computed when results submitted
    white_board_points: float = 0.0
    black_board_points: float = 0.0
    white_match_points: float = 0.0  # 1/0.5/0
    black_match_points: float = 0.0


# --------------------------
# Round (Group or Swiss)
# --------------------------

@dataclass
class Round:
    round_number: int
    matches: List[TeamMatch] = field(default_factory=list)
    is_completed: bool = False


# --------------------------
# Pool (Group Stage)
# --------------------------

@dataclass
class Pool:
    id: str = field(default_factory=gen_id)
    name: str = ""
    team_ids: List[str] = field(default_factory=list)
    rounds: List[Round] = field(default_factory=list)


# --------------------------
# Swiss Tournament Container
# --------------------------

@dataclass
class SwissTournament:
    qualified_team_ids: List[str] = field(default_factory=list)
    rounds: List[Round] = field(default_factory=list)


# --------------------------
# Global Tournament State
# --------------------------

@dataclass
class TournamentState:
    name: str = ""
    stage: Literal["group", "swiss", "complete"] = "group"

    teams: Dict[str, Team] = field(default_factory=dict)
    players: Dict[str, Player] = field(default_factory=dict)
    pools: List[Pool] = field(default_factory=list)

    swiss: Optional[SwissTournament] = None

    created_at: str = ""
    last_updated: str = ""
