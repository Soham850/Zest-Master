import streamlit as st
import json
from pathlib import Path

st.set_page_config(
    page_title="Chess Team Tournament Manager",
    layout="wide"
)

# Paths
DATA_DIR = Path("data/tournaments")
ACTIVE_DIR = DATA_DIR / "active"
ARCHIVE_DIR = DATA_DIR / "archive"

def load_state(slug: str):
    path = ACTIVE_DIR / slug / "state.json"
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ──────────────────────────────────────────────
# Sidebar navigation
# ──────────────────────────────────────────────

sections = [
    "Tournaments",
    "Teams & Players",
    "Group Stage",
    "Swiss Stage",
    "Standings"
]

selection = st.sidebar.radio("Navigate:", sections)


# ──────────────────────────────────────────────
# Auto Smart Resume Logic
# ──────────────────────────────────────────────

active_slug = st.session_state.get("active_tournament", None)
view_slug = st.session_state.get("view_tournament", None)

if active_slug:
    state = load_state(active_slug)

    if state is None:
        st.error("Cannot load tournament state. File missing or corrupted.")
        st.session_state.pop("active_tournament", None)
        st.stop()

    # Smart resume based on stage — unless manually overridden via sidebar
    if selection == "Tournaments":
        # allow manual change to tournaments screen
        pass
    else:
        stage = state.get("stage", "group")

        if stage == "group" and selection not in ["Teams & Players", "Group Stage"]:
            selection = "Group Stage"

        elif stage == "swiss" and selection not in ["Swiss Stage", "Standings"]:
            selection = "Swiss Stage"

        elif stage == "complete" and selection != "Standings":
            selection = "Standings"


elif view_slug:
    # View-only mode for archived or snapshot
    state = load_state(view_slug)  # or adjust for archived view
    if state is None:
        st.error("Cannot view tournament state.")
        st.session_state.pop("view_tournament", None)
        st.stop()
    # Force navigation to view mode locations
    if selection not in ["Tournaments", "History & Snapshots"]:
        selection = "History & Snapshots"


# ──────────────────────────────────────────────
# Route to UI Pages
# ──────────────────────────────────────────────

if selection == "Tournaments":
    import UI.tournaments as page
    page.render()

elif selection == "Teams & Players":
    import UI.teams_players as page
    page.render(active_slug)

elif selection == "Group Stage":
    import UI.group_stage as page
    page.render(active_slug)

# elif selection == "Qualification":
#     import ui.qualification as page
#     page.render(active_slug)

elif selection == "Swiss Stage":
    import UI.swiss_stage as page
    page.render(active_slug)

elif selection == "Standings":
    import UI.standings as page
    page.render(active_slug)

# elif selection == "History & Snapshots":
#     import ui.history as page
#     page.render(active_slug, view_slug)

# elif selection == "Settings":
#     import ui.settings as page
#     page.render()
